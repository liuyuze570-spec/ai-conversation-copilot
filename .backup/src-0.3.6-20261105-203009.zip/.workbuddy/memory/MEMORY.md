# 项目长期记忆：AI Conversation Copilot

Windows 桌面端实时多语言（英/俄/日/韩）对话副驾驶。栈：Electron 33 + React 18 + TS + Vite 5 + Tailwind 3 + Python sidecar（soundcard WASAPI 回环）。
工作区 `F:/3D打印Rhino 7.0/2026-09-30-23-01-15`；用户数据 `C:/Users/25344/AppData/Roaming/ai-conversation-copilot`（settings.json、logs/app.log）。

## 产品
- 三种场景（`settings.scenarioMode`）：`conversation` 实时对话 / `video` 看视频 / `exam` 四六级听力。后两种常显实时翻译条 + 停顿 `pauseDetectMs`（默认 2.5s）后自动出回复（静音看门狗，不操控播放器）。`Alt+V` 切场景。
- 默认真实采集（`mockMode=false`）：WASAPI 回环抓系统默认输出，任何软件都能听。`mockMode=true` 是演示模式，碰不到声卡，UI 有橙色横幅。
- 用户偏好：中文沟通；要"直接开发并运行验证"，不接受只给方案；回复必须"能说出口"（短、口语、按国内等级分级）；默认不自动回复，Alt+Space 触发；隐私优先（不存音频、Key 用 DPAPI 加密）。

## 音频链路
- `vendor/python-runtime/`（60MB，Python embeddable + numpy + soundcard）由 `npm run prepare:py` 组装，打包进 `resources/python-runtime/`。这就是"发给朋友不用装 Python"的基础。解释器发现顺序：内置运行时 → 配置路径 → 内置 venv → PATH，每个候选都真跑 `import soundcard, numpy` 校验。
- `loopback.py` 用 stderr JSON 事件（`started/level/silent/error`）上报 → `python-engine.ts` 逐行解析 → IPC `audio:level`。格式自适应（16k/48k/44.1k × 2ch/1ch）。
- **系统静音不影响采集（已实测结案，别再排查）**：回环取样点在端点音量/静音之前，满音量/静音/对照三者 RMS 只差 1.0%（噪声底线），不放声音时本底为 0。脚本 `.dev/mute-loopback-test.py`。
- 自适应切句门槛 `shared/adaptive-vad.ts`：旧实现固定下限 `max(200, 噪声*2.4)` 会整段丢掉小声对白；现跟近期峰值（`PEAK_DECAY=0.98`）往下走但**永不高于 200**，`ABSOLUTE_FLOOR=80` 兜底。不变量：字幕只会变多不会变少。
- 转录队列：`TRANSCRIBE_DEADLINE_MS=25s` + `MAX_QUEUE_BACKLOG=4`，不要退回布尔互斥量（一次卡死=之后全没字幕）。
- 看门狗门槛 `shared/audio-status.ts#canWatchForPause()` 允许 `listening | no-audio`；`main/audio/status-heal.ts` 在有信号时把状态捞回 listening（旧 bug：一次 silent 事件让整场自动回复永久失效）。

## 一键诊断（0.3.4）
- `shared/health.ts`（`HealthItem{level:ok|warn|fail}` + `visibleIssues` + `healthSummary`）→ `main/audio/health-check.ts` → IPC `SYSTEM_CHECK` → `HealthView.tsx`。
- **规则：没点按钮不显示任何结果；点了只显示有问题的项**，全绿只一行「检查完成，没有发现问题」。有 fail 时标题写「发现 N 个问题、M 条建议」。
- 检查：演示模式 → 采集开关 → Python 组件 → 默认扬声器（probeAudio 2.5s）→ 采样率 → 有无声音 → STT/LLM Key → **真发一次请求 `testAIConnection`（12s 上限）** → 推理型模型告警。
- 真发请求这条最值钱：2026-11-02 实测「Key 在、设备正常、采集在跑，就是没字幕」= 服务商 **HTTP 402 余额不足**。不真打永远发现不了。
- 不做音量/静音检查（见上，静音不影响）。`AudioDiagnostics` 的「已经听到声音」分支也要有诊断入口——那正是"有声音没字幕"的真实场景。

## 语言水平（0.3.4）
- `shared/levels.ts`：英语 6 档（B级/A级/四级/六级/专四/专八）、俄语 5 档（入门/大学俄语四六/专业四八）、日语 5 档（JLPT N5→N1）、韩语 6 档（TOPIK 1→6）。
- 唯一真相是 `settings.languageLevels: Record<TargetLanguage,string>`；`englishLevel` 只是投影（`get()` 里算），写它会被 `update()` 折进 `languageLevels.English`。
- 迁移顺序：**先看 languageLevels.English 是否合法，再看旧 englishLevel**，反了会让用户改好的值每次启动被改回去。
- 提示词 `levelGuidance(language, level)` 按语言取表；串门值（日语收到 `cet4`）回**该语言**默认档。**不要再用 CEFR 的 A1–C1（用户觉得像驾照）。**

## 语气 / 风格
- 两项都是硬约束：`prompts.ts#moodGuide()` 在指定情绪时写「MOOD — 固定为「X」（用户选的，必须照做）」+ 三条禁止（不许换情绪/不许弱化成中立/不许被对方的话覆盖）；`auto` 才让模型读对方最后一句判断情绪。
- `STYLE_TONE_NOTE` 写死优先级：风格管用词与正式度，语气管情绪；冲突时按用户设置（正式+调侃=克制的冷幽默）。
- 表达库按语气裁剪 `tone.ts#expressionGuideFor(tone, style)`：以前整库（含 "I'm dead"、"lowkey yes"）无条件塞进提示词，正式风格下模型两条都不听。`formal` 还要砍掉网络俚语与亲密表达。
- 改了风格/长度/等级/语气/语言 → `useCopilot` 的 `styleSignature` 会重出回复，且**不许抢走用户打开的面板**（`shared/reply-reveal.ts`：用户主动要的才 reveal，自动来的 reveal:false）。

## 注音字段一律当脏数据（0.3.3）
`services/pronunciation.ts` 逐字段把关 `ipaLooksWrong` / `syllablesLookWrong` / `chinesePronLooksWrong` / `tidyChinese`，不可信就丢或换本地引擎（**空着比错着安全**）。模型实测会给出：中文拼音当 ipa、抄英文原文、混天城文/希腊字母；syllables 写中文词/重复两遍/纯标点块；谐音写成中文句子自己的注音或整句中文带标点；译文逐字空格。最值钱的判据：ipa 字符白名单一票否决、**拼音声调符号单独判**（`ā` 在拉丁扩展区白名单里拦不住）、syllables **拼回去必须等于原句**、谐音**一个标点都不该有**。`romanization` 在英语模式无条件丢。
7B 模型对长指令耐受度低：提示词写长了反而出裸 `{}`、丢字段、坏 JSON，细节交给代码兜底。

## 时延 / 性能页
- 链路 `shared/latency.ts`（统计+结论纯函数）→ `main/latency.ts`（内存环形，80 记录/24 回复，不落盘）→ IPC → `PerformanceSettings.tsx`。
- `traceId` 把识别与翻译合成一轮端到端（`TranscriptPayload.traceId` → 翻译带回）。
- 实时率 RTF = sttMs/audioMs 是最关键指标（与网速无关），≥1.15 判 bad。`probeSttLatency()`（`LATENCY_PROBE_STT`）自造 3 秒类语音 WAV 打真接口，`synthSpeechLikeWav()` **刻意不用纯正弦**（会被当静音短路）。
- **单次测量不可信**：实测识别 381/11177/3030/5232/516ms（RTF 0.13~3.73，波动 29 倍）；回复平均 7~9.6 秒、尾部 15 秒以上 → 回复才是真瓶颈。所以测速累积成分布，卡片显示「平均 + 最慢 5%」。

## UI 约定
- **下拉一律用 `controls.tsx` 的自绘 `Select`，禁止原生 `<select>`**：窗口是无边框+置顶+`backdrop-filter`+内部滚动，原生弹层会被裁切/点不动。要点：`createPortal` 到 body + `position:fixed`、打开时按 rect 现算（可朝上弹）、滚动只重定位不关闭、触发器 `onMouseDown` preventDefault。触发器上读 `getAttribute('data-value')`。
- `Button`/`Select`/`Hint` 的 `dataAttr` 传**完整属性名**（`data-perf-clear`），传短名会生成 `perf-clear=""`。
- 选项配置在 `shared/types.ts`；`executeJavaScript` 模板字符串里**不能用反引号**（会截断外层，tsc 报 TS1005）。
- Tailwind 3.4 的 `opacity` 刻度默认只有 5 的倍数，`bg-white/8` 之类**不报错也不生成 CSS**；已补全 0–100，但新加颜色后要 grep `dist/renderer/assets/*.css` 核对。
- 设计令牌在 `tailwind.config.js`（`ink-*` 表面阶梯、`line-soft/line/line-strong`、`accent`、`ok/warn/danger`），不要再写 emerald/amber/rose。

## 环境约束（踩过很贵的坑）
- 项目路径含中文 → app-builder.exe 崩溃，打包必须 `npm run dist:win`（走 ASCII 暂存目录）。
- 该环境 GPU 崩溃 → 主进程 `disableHardwareAcceleration` + `disable-gpu`；`transparent:true` + GPU 合成禁用会让**整个窗口不可见**（进程在、窗口在、屏幕上看不到），已改不透明深色。
- 生产加载必须用 `copilot://` 协议（`file://` 下 ES module 被 CORS 拦，症状：DOM 全空）。
- 启动一律走 `scripts/start-electron.js`（宿主设了 `ELECTRON_RUN_AS_NODE=1`，必须清掉）。打包版从命令行启动同样要清，否则 exe 秒退、stdout 空。
- 沙箱：`spawnSync` 间歇性 `EBUSY`（sidecar 起不来，是环境不是回归）；`fs.cpSync` 对**目录**静默无操作 → 自己写 readdir+copyFile 递归并在复制后验证。
- **单实例锁会让自检静默失败**：用户开着打包版时，`COPILOT_SCREENSHOT` 新实例拿不到锁 → `exit=0`、stdout 全空、无截图、日志无新记录。先查这个再看代码。
- `capturePage` 对这个窗口不完全可靠；抓"某面板处于某状态"的截图，必须让 `executeJavaScript` 的**最后一步**停在那状态。设置页内部滚动容器的 `scrollIntoView` 不可靠，要按 rect 差值改 `scrollTop`。
- **永远不要 rm 用户的 app.log**（犯过一次）；要清先 `cp` 备份。`.dev/multi-round-repro.js` 内部会删日志，跑前备份。
- 跑完自检必须还原 settings：`scenarioMode` 会停在 video、`window.bounds` 会变成设置面板尺寸。还原成 conversation / 460×640 / mockMode=false / tone=auto / 目标语言 English。

## 验证纪律
- 规则类改动一律抽纯函数 + 单测 import `dist/` 产物（=真正跑在用户机器上的代码）。现有：`.dev/levels-health-unit.mjs`(69)、`pron-unit.mjs`(53)、`latency-vad-unit.mjs`(80)、`reply-reveal-unit.mjs`(16)。
- **自检里的异步等待绝不能读 React 的 `disabled`**（`click()` 返回时 state 未提交，读到永远 false）→ 用用户可见信号（按钮文案、结果区 textContent）。
- 同一份代码两次自检一次全绿一次全红时，别改断言：从 `app.log` 按时间线对齐断言窗口，典型根因是异步状态改动抢走了被测 DOM。
- `.dev/llm-probe.js` 是拿「模型真实返回」的探针（独立 Electron，不抢锁；`safeStorage` 解 DPAPI；四个 GPU 开关一个都不能少）。它要自己复刻产品侧 `.filter(item=>item.english)`，别拿它当产品替身。

## 尚未完成 / 下一步
- **回复链路仍是全非流式**：`transcribe()` 无 partial、`translate()` 返回全文、`http.ts` 零 SSE。实测回复平均 8 秒 → 排序：① 回复改流式（首卡先出）② 回复预取（VAD 确认静音那 1~2.5s 本来白等）③ 翻译流式。
- **Electron 原生抓音频未实测**：`getDisplayMedia({audio:true})` + `setDisplayMediaRequestHandler` 可绕开 Python sidecar，是"sidecar 起不来就变砖"的正解。
- 产品定位：从「翻译器」转向「接话教练」（没人解决"我该说什么"）。候选：接话骨架、"我没跟上"逃生舱、语气自动判断、生词本。四六级听力是最好的切入口。
- 口语纠错（`speakingCorrection` 有开关未接入）、学习记录/Summary、安装包图标与代码签名（当前无签名，教程已教朋友怎么点「仍要运行」）。
- **用户账户余额**：2026-11-02 实测 SiliconFlow 返回 HTTP 402（`reply/translate` 全失败）。这类"配置都对但没钱"的问题诊断页已能报出来。

## 安全与稳定不变量（0.3.6 起，别退化）
- **Key 绑定服务商**：`settings.keyBindings` 记**完整 origin**（`scheme://host[:port]`，默认端口省略）；`keyOwnership()` 三态 ok/mismatch/**unknown**（unknown 也停用）；`getApiKey()` 非 ok 一律返回空。切换服务商后旧 Key 不许发出去（界面写「Key 属于上一家」而不是「没填 Key」）。迁移必须**先记 origin 再绑**（明文分支最容易漏，0.3.6 就是这里漏的）；公网 http→https 升级时用 `followSchemeUpgrade()` 让绑定跟随（只认同主机同端口的升级，**降级绝不跟随**）。
- **公网强制 https**，只有 localhost/内网允许 http 且必须标「本机服务」。迁移时用 `enforceHttps()` **只升级 scheme，绝不换服务商**。
- **明文永不落盘**：无 `safeStorage` 时 Key 只进内存（重启要重填）。迁移顺序必须是 `load → migrateKeyStorage → 其它`，且 `persist()` 要先救进内存再删字段（顺序写反 = 静默丢 Key）。
- **渲染层拿不到完整 Key**：只有 `getApiKeyPreview()`（脱敏）。所有请求在主进程发。
- **敏感 IPC 要验来源**（`isTrustedSender`：主 frame + copilot:// / file:// / 非打包 localhost）。
- **切句三闸门独立**（`shared/segment-vad.ts`）：静音→够长收官/不够丢弃；时长上限；字节上限。**不许再写成 `enoughSpeech && (...)`** —— 短噪声会让缓冲区无限增长。
- **音频有会话编号**：停止/重启 +1，旧字幕/旧状态一律丢弃；`stop()` 必须 abort 在途 STT。
- **STT 成功后 `error`/`no-audio` 都要捞回 `listening`**，否则一次失败 = 整场自动回复永久失效。
- **HTTP 超时是总预算，必须盖住读 body**；401/402/403 不重试；只有 400/404/422 才换请求体降级。
- **回复请求要带 seq + 发起时的 round 快照**；关面板后迟到结果不许再弹。
- **CSP 必须有 `media-src 'self' data:`**，否则云端朗读静默无声（不报错）。
- **Electron 33 已 EOL（2025-04-28）**，当前稳定版 45；升级待排。
- **启动音频管线要幂等**（`shared/pipeline-gate.ts`）：主进程开机自动启动 + 渲染层 `status==='idle'` 自我启动必然撞车，`startAudioPipeline` 配置没变就**不许** stop→start（否则每次开机白起一个 python 采集进程）。指纹只含 mock/采集开关/设备/python 路径；`demoAutoPlay`+`targetLanguage` **仅在 mock 下计入**；**不含 sttProvider**。
- **字幕译文四态**（`shared/subtitle-state.ts`）：idle/pending/ok/failed/cancelled，失败与取消必须给逐句重试入口；**有译文一律算 ok**（半句已译出、整句失败不能回退成「翻译失败」）；停止监听把 pending 转 **cancelled**，不能写成 failed。
- **打包前必须 `npm run build`**：`dist:win` 只快照 `dist/`，不重跑渲染构建；打完后 `grep -c <新字符串> app.asar` 核对，0 就说明包里是旧产物。
- **音频完结必须「先快照再重置」**（`main/audio/segment-buffer.ts`）：旧代码先 `segmentState = reset()`（bytes=0）再 `Buffer.concat(chunks, 0)`，返回零长度 Buffer → 完整识别从未提交。`snapshot()` **不许接受外部字节数参数**，那就是 bug 入口。时长唯一口径是 `totalChunks * chunkMs`（`speechChunks+silenceChunks` 会漏算中途停顿，上限晚触发约 4 秒）。
- **日志只记状态 / 错误码 / 字数 / 耗时**：正文、译文、事实内容、模型原始返回、服务商回显的请求体都不许进 `app.log`。用 `logger.describeError()`（有 status 只留 `HTTP_402`）。`logger.debug()` 只在 dev 打控制台。核对办法：grep 一句话/`sk-`/`enc:` 于 `logs/app.log`。
- **取消要真 abort，不只是丢结果**：`aiInflight` + IPC `ai:cancel` 按 requestId 精确取消（翻译 `tr:`、回复 `rp:`、朗读 `tts:`、事实 `fx:`、确认句 `cf:`）。超时与用户取消必须分别上报；译文标成 cancelled 后迟到响应**不许改回 ok**。
- **会话清场只有一条路**：`renderer/lib/session-reset.ts` 的 `resetLiveSession()`（由 `useCopilot` 注册）。`useSessions()` 在 App 和 RecordsPanel 各实例化一次，**参数传不进去**；四个入口（新建/打开/删除/全清）都必须走这个单例，否则事实卡和迟到译文会串到新会话。
- **事实卡**：规则提取（时间/日期/金额/数量，本地零成本）优先，模型只补人名/机构/事项；`sourceText` 必须能在字幕里找到否则丢弃；双语同一件事用 `mergeBilingual()` 合并成一行（值取译文、片段取原文）；同一条字幕第二次提取用 `replaceRuleFacts()` 替换，但 `edited`/`confirmed` 的行保留。确认句若出现选中事实之外的新数字就拦下。
- **460×640 布局**：QuickActions 必须 `shrink-0`（否则主按钮被挤出屏幕）；事实卡 body 用 `max-h-[min(9rem,28vh)]`（`max-h-52` 会把字幕压到 16px）。布局问题用 `COPILOT_FACTS_PROBE=1` 量矩形，别靠猜。
- **进包核对要用字节比对**：压缩后函数名会变，grep 函数名不能当证据；用 `asar.extractFile('...app.asar','dist\\renderer\\assets\\index-*.js')` 与 `dist/renderer/assets/` 比 `equals()`。
