import { create } from 'zustand';
import type { ConversationItem, TargetLanguage } from '../../shared/types';

/**
 * Conversation records (会话记录).
 *
 * Privacy rule: everything here lives in memory only. Nothing is written to
 * disk unless the user explicitly exports a record. Records are dropped when
 * the app closes.
 */
export interface ConversationRecord {
  id: string;
  title: string;
  language: TargetLanguage;
  createdAt: number;
  updatedAt: number;
  items: ConversationItem[];
}

interface RecordState {
  records: ConversationRecord[];
  /** Id of the record currently being edited (null = a fresh, unsaved chat). */
  activeId: string | null;
  /** Persist (or refresh) the live conversation into a record. */
  saveCurrent: (items: ConversationItem[], language: TargetLanguage) => string | null;
  /** Archive the live conversation and start a brand-new empty one. */
  startNew: (items: ConversationItem[], language: TargetLanguage) => void;
  open: (id: string) => ConversationItem[];
  remove: (id: string) => void;
  clearAll: () => void;
  setActive: (id: string | null) => void;
}

const MAX_RECORDS = 50;

let counter = 0;
function nextId(): string {
  counter += 1;
  return `r${Date.now().toString(36)}-${counter}`;
}

/** Record title = first foreign utterance (fallback: first line, then time). */
function deriveTitle(items: ConversationItem[]): string {
  const meaningful = items.filter((item) => !item.partial && item.originalText.trim());
  const first = meaningful.find((item) => item.speaker === 'foreign') ?? meaningful[0];
  if (!first) return '（空对话）';
  const text = first.originalText.replace(/\s+/g, ' ').trim();
  return text.length > 28 ? `${text.slice(0, 28)}…` : text;
}

export const useRecordStore = create<RecordState>((set, get) => ({
  records: [],
  activeId: null,

  saveCurrent: (items, language) => {
    const meaningful = items.filter((item) => !item.partial && item.originalText.trim());
    if (!meaningful.length) return null;

    const { records, activeId } = get();
    const now = Date.now();
    const existing = activeId ? records.find((record) => record.id === activeId) : undefined;

    if (existing) {
      set({
        records: records.map((record) =>
          record.id === existing.id
            ? {
                ...record,
                items: meaningful,
                language,
                updatedAt: now,
                title: deriveTitle(meaningful),
              }
            : record,
        ),
      });
      return existing.id;
    }

    const created: ConversationRecord = {
      id: nextId(),
      title: deriveTitle(meaningful),
      language,
      createdAt: now,
      updatedAt: now,
      items: meaningful,
    };
    set({ records: [created, ...records].slice(0, MAX_RECORDS), activeId: created.id });
    return created.id;
  },

  startNew: (items, language) => {
    get().saveCurrent(items, language);
    set({ activeId: null });
  },

  open: (id) => {
    const record = get().records.find((item) => item.id === id);
    if (!record) return [];
    set({ activeId: id });
    return record.items;
  },

  remove: (id) =>
    set((state) => ({
      records: state.records.filter((record) => record.id !== id),
      activeId: state.activeId === id ? null : state.activeId,
    })),

  clearAll: () => set({ records: [], activeId: null }),

  setActive: (id) => set({ activeId: id }),
}));
