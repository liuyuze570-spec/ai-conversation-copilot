import { create } from 'zustand';
import type { ConversationItem } from '../../shared/types';
import type { TranscriptPayload } from '../../shared/ipc';
import type { TranslationState } from '../../shared/subtitle-state';
import { cancelPendingTranslation } from '../../shared/subtitle-state';

interface ConversationState {
  items: ConversationItem[];
  /** id of the item currently being streamed (partial). */
  partialId: string | null;
  /**
   * 现在是第几「轮」。
   *
   * 一轮 = 对方说完一句外语。看视频 / 做听力时用户真正关心的是「刚刚那轮我
   * 该怎么接」，所以轮次要显式暴露出来：界面上显示「第 N 轮」，回复面板也知道
   * 自己手上的三张卡是哪一轮的 —— 否则新一轮开始后旧卡片还挂在那里，看起来
   * 就像「第二轮没被监听」（用户原话：「无法开启第二轮对话监听」）。
   */
  roundIndex: number;
  /** 最近一轮外语原文，用于「新一轮」提示与快捷操作。 */
  lastForeignText: string;
  /** Ingests a transcript event. Returns the finalized item, if any. */
  upsert: (payload: TranscriptPayload) => ConversationItem | null;
  setTranslation: (id: string, translatedText: string) => void;
  /**
   * 只改译文状态、不动译文。翻译失败 / 被取消时用它，界面才有东西可提示。
   */
  setTranslationState: (id: string, state: TranslationState) => void;
  /** 停止监听时把还在翻的字幕标成「已取消」（不是失败，用词要区分）。 */
  cancelPendingTranslations: () => void;
  setCorrection: (id: string, correction: string, note: string) => void;
  clear: () => void;
  /** Replace the live transcript (used when opening a saved record). */
  loadItems: (items: ConversationItem[]) => void;
  /** How many utterances are kept for scrolling (settings controlled). */
  historyLimit: number;
  setHistoryLimit: (limit: number) => void;
  /** Recent conversation formatted for the LLM prompt. */
  contextText: (limit?: number) => string;
  recentItems: (limit?: number) => ConversationItem[];
  /** The utterance currently being streamed, if any (used for live translation). */
  partialItem: () => ConversationItem | null;
  /** Most recent finalized foreign utterance (used by the live subtitle bar). */
  lastForeign: () => ConversationItem | null;
}

/** Hard ceiling: enough to scroll through a long call, small enough for memory. */
const MAX_ITEMS = 2000;
const CONTEXT_WINDOW_MS = 60_000;

let counter = 0;
function nextId(): string {
  counter += 1;
  return `${Date.now().toString(36)}-${counter}`;
}

export const useConversationStore = create<ConversationState>((set, get) => ({
  items: [],
  partialId: null,
  roundIndex: 0,
  lastForeignText: '',
  historyLimit: 400,

  upsert: (payload) => {
    const { items, partialId } = get();
    const limit = Math.min(get().historyLimit, MAX_ITEMS);
    const trimmed = payload.text.trim();
    if (!trimmed) return null;

    if (payload.partial) {
      // Keep streaming into the same bubble while it is still partial.
      const existing =
        partialId !== null ? items.find((item) => item.id === partialId) : undefined;
      if (existing && existing.speaker === payload.speaker) {
        const updated = items.map((item) =>
          item.id === existing.id ? { ...item, originalText: trimmed } : item,
        );
        set({ items: updated });
        return null;
      }
      const created: ConversationItem = {
        id: nextId(),
        timestamp: Date.now(),
        speaker: payload.speaker,
        originalText: trimmed,
        confidence: payload.confidence,
        partial: true,
      };
      set({ items: [...items, created].slice(-limit), partialId: created.id });
      return null;
    }

    // Final result: reuse the partial bubble so the subtitle does not jump.
    const existing =
      partialId !== null ? items.find((item) => item.id === partialId) : undefined;
    // 一句外语定稿 = 新一轮开始。轮次是「多轮对话监听」在界面上的锚点：
    // 没有它，用户根本分不清「第二轮没被监听」和「第二轮正在听」。
    const foreignRound =
      payload.speaker === 'foreign'
        ? { roundIndex: get().roundIndex + 1, lastForeignText: trimmed }
        : {};
    let finalized: ConversationItem;
    if (existing && existing.speaker === payload.speaker) {
      finalized = {
        ...existing,
        originalText: trimmed,
        confidence: payload.confidence ?? existing.confidence,
        partial: false,
      };
      set({
        items: items
          .map((item) => (item.id === existing.id ? finalized : item))
          .slice(-limit),
        partialId: null,
        ...foreignRound,
      });
    } else {
      finalized = {
        id: nextId(),
        timestamp: Date.now(),
        speaker: payload.speaker,
        originalText: trimmed,
        confidence: payload.confidence,
        partial: false,
      };
      set({ items: [...items, finalized].slice(-limit), partialId: null, ...foreignRound });
    }
    return finalized;
  },

  setTranslation: (id, translatedText) =>
    set((state) => ({
      items: state.items.map((item) =>
        item.id === id ? { ...item, translatedText, translationState: 'ok' as const } : item,
      ),
    })),

  setTranslationState: (id, translationState) =>
    set((state) => ({
      items: state.items.map((item) => (item.id === id ? { ...item, translationState } : item)),
    })),

  cancelPendingTranslations: () =>
    set((state) => {
      let changed = false;
      const items = state.items.map((item) => {
        const next = cancelPendingTranslation(item.translationState);
        if (next === item.translationState) return item;
        changed = true;
        return { ...item, translationState: next as TranslationState };
      });
      return changed ? { items } : {};
    }),

  setCorrection: (id, correction, note) =>
    set((state) => ({
      items: state.items.map((item) =>
        item.id === id ? { ...item, correction, correctionNote: note } : item,
      ),
    })),

  clear: () => set({ items: [], partialId: null, roundIndex: 0, lastForeignText: '' }),

  loadItems: (items) =>
    set({
      items: items.slice(-MAX_ITEMS),
      partialId: null,
      roundIndex: items.filter((item) => item.speaker === 'foreign' && !item.partial).length,
      lastForeignText:
        [...items].reverse().find((item) => item.speaker === 'foreign' && !item.partial)
          ?.originalText ?? '',
    }),

  setHistoryLimit: (limit) =>
    set({ historyLimit: Math.min(MAX_ITEMS, Math.max(20, Math.floor(limit))) }),

  recentItems: (limit = 12) => {
    const items = get().items.filter((item) => !item.partial);
    const cutoff = Date.now() - CONTEXT_WINDOW_MS;
    const windowed = items.filter((item) => item.timestamp >= cutoff);
    return (windowed.length ? windowed : items).slice(-limit);
  },

  partialItem: () => {
    const { items, partialId } = get();
    if (partialId === null) return null;
    return items.find((item) => item.id === partialId) ?? null;
  },

  lastForeign: () => {
    const items = get().items;
    for (let index = items.length - 1; index >= 0; index -= 1) {
      if (items[index].speaker === 'foreign') return items[index];
    }
    return null;
  },

  contextText: (limit = 12) =>
    get()
      .recentItems(limit)
      .map((item) => {
        const label = item.speaker === 'foreign' ? 'Foreign' : 'You';
        return `${label}: ${item.originalText}`;
      })
      .join('\n'),
}));
