import { create } from 'zustand';
import type { FactItem } from '../../shared/facts';

/**
 * 关键事实卡的内存存储。
 *
 * 只活在当前会话：不写磁盘、不进日志、切换 / 清空对话就整个丢掉
 * （审计要求「事实卡默认只保存在当前会话内存」「新建会话或清空记录时同步
 * 清理事实和在途任务」）。
 */

/** 上限：一场两小时的会也够用，又不会让内存无界增长。 */
const MAX_FACTS = 300;

interface FactsState {
  items: FactItem[];
  /** 勾选了哪些（生成确认句只用这些）。 */
  selected: Record<string, true>;
  /** 正在生成确认句。 */
  confirming: boolean;
  /** 最近一次生成结果（用户可复制 / 朗读）。 */
  draft: { sentence: string; chinese: string; factIds: string[] } | null;
  /** 生成失败的一句话。 */
  error: string | null;

  /** 新的一批事实（同一条字幕重复提取时按内容去重）。 */
  addMany: (items: FactItem[]) => void;
  /**
   * 用「最新一次的规则结果」替换这条字幕之前的规则结果。
   *
   * 为什么需要：同一条字幕会被提取两次 —— 定稿时只有原文，译文回来后还要
   * 再跑一次（中文里的「明天下午三点」只有这时才认得出）。如果只是追加，
   * 界面就会出现
   *     日期  Tomorrow   ← 第一次留下的
   *     日期  明天       ← 第二次合并后的（片段是 Tomorrow）
   * 同一件事两行。规则事实以最后一次为准；用户手动改过 / 确认过的行保留，
   * 不能被自动结果覆盖掉。
   */
  replaceRuleFacts: (itemId: string, items: FactItem[]) => void;
  update: (id: string, patch: { value?: string; status?: FactItem['status'] }) => void;
  remove: (id: string) => void;
  toggleSelected: (id: string) => void;
  clearSelection: () => void;
  setConfirming: (value: boolean) => void;
  setDraft: (draft: FactsState['draft']) => void;
  setError: (message: string | null) => void;
  /** 清空（新建会话 / 清空记录 / 停止监听时调用）。 */
  clear: () => void;
  forItem: (itemId: string) => FactItem[];
}

export const useFactsStore = create<FactsState>((set, get) => ({
  items: [],
  selected: {},
  confirming: false,
  draft: null,
  error: null,

  addMany: (incoming) => {
    if (!incoming.length) return;
    const { items } = get();
    const seen = new Set(
      items.map((item) => `${item.kind}|${item.value.trim().toLowerCase()}|${item.itemId}`),
    );
    const fresh: FactItem[] = [];
    for (const item of incoming) {
      const key = `${item.kind}|${item.value.trim().toLowerCase()}|${item.itemId}`;
      if (seen.has(key)) continue;
      seen.add(key);
      fresh.push(item);
    }
    if (!fresh.length) return;
    set({ items: [...items, ...fresh].slice(-MAX_FACTS) });
  },

  replaceRuleFacts: (itemId, incoming) => {
    const state = get();
    /*
     * 只替换「还保持自动态」的行：用户改过值（edited）或确认过（confirmed）
     * 的一律原样留着 —— 自动提取没有资格覆盖人的判断。
     */
    const keepOthers = state.items.filter(
      (item) =>
        !(
          item.itemId === itemId &&
          item.id.startsWith('fr-') &&
          !item.edited &&
          item.status === 'pending'
        ),
    );
    const droppedIds = new Set(
      state.items
        .filter(
          (item) =>
            item.itemId === itemId &&
            item.id.startsWith('fr-') &&
            !item.edited &&
            item.status === 'pending',
        )
        .map((item) => item.id),
    );
    const seen = new Set(
      keepOthers.map((item) => `${item.kind}|${item.value.trim().toLowerCase()}|${item.itemId}`),
    );
    const fresh = incoming.filter((item) => {
      const key = `${item.kind}|${item.value.trim().toLowerCase()}|${item.itemId}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
    const selected = { ...state.selected };
    for (const id of droppedIds) delete selected[id];
    const draft =
      state.draft && state.draft.factIds.some((id) => droppedIds.has(id)) ? null : state.draft;
    set({
      items: [...keepOthers, ...fresh].slice(-MAX_FACTS),
      selected,
      draft,
    });
  },

  update: (id, patch) =>
    set((state) => ({
      items: state.items.map((item) => {
        if (item.id !== id) return item;
        const next: FactItem = { ...item };
        if (typeof patch.value === 'string') {
          const value = patch.value.trim();
          if (!value) return item;
          // 记住改之前的样子：更正信息时要保留来源与「已修改」提示。
          if (!next.edited) next.originalValue = item.value;
          next.value = value;
          next.edited = true;
        }
        if (patch.status) next.status = patch.status;
        return next;
      }),
    })),

  remove: (id) =>
    set((state) => {
      const selected = { ...state.selected };
      delete selected[id];
      return {
        items: state.items.filter((item) => item.id !== id),
        selected,
        // 删掉的那条如果正好在确认句里，结果也不再成立。
        draft: state.draft?.factIds.includes(id) ? null : state.draft,
      };
    }),

  toggleSelected: (id) =>
    set((state) => {
      const selected = { ...state.selected };
      if (selected[id]) delete selected[id];
      else selected[id] = true;
      // 选中内容变了，上一次的确认句就不再对应，避免用户复制到旧句子。
      return { selected, draft: null, error: null };
    }),

  clearSelection: () => set({ selected: {}, draft: null, error: null }),

  setConfirming: (confirming) => set({ confirming }),
  setDraft: (draft) => set({ draft }),
  setError: (error) => set({ error }),

  clear: () =>
    set({ items: [], selected: {}, confirming: false, draft: null, error: null }),

  forItem: (itemId) => get().items.filter((item) => item.itemId === itemId),
}));
