import { useCallback, useEffect, useRef } from 'react';
import { useConversationStore } from '../stores/conversation';
import { useRecordStore } from '../stores/records';
import { useSettingsStore } from '../stores/settings';
import { useUiStore } from '../stores/ui';
import { resetLiveSession } from '../lib/session-reset';

/**
 * Bridges the live transcript with the in-memory conversation records:
 * auto-saves the running chat, starts new ones and re-opens old ones.
 *
 * ## 为什么每个入口都要走 `resetLive`
 *
 * 切会话不只是「换一批字幕」。事实卡是**按当前会话**存在的，在途的翻译、
 * 回复、事实提取也是按当前会话发出去的。只清字幕会留下两个后果：
 *   1. 上一场的「明天下午三点」还挂在新的空白会话上 —— 用户会以为它记错了;
 *   2. 几百毫秒后才返回的译文/事实被追加到新会话里 —— 串场，且无法解释。
 *
 * `resetLive` 由 `useCopilot().clearConversation` 提供，它负责取消所有在途
 * 请求（含朗读）、清事实和在选择态、清字幕和建议。这里只保证**四个入口
 * 全都调用它**，而不是各自清一半。
 */
export function useSessions() {
  const records = useRecordStore((state) => state.records);
  const activeId = useRecordStore((state) => state.activeId);
  const items = useConversationStore((state) => state.items);
  const language = useSettingsStore((state) => state.settings.targetLanguage);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  /**
   * 清空「当前这场对话」的一切。
   *
   * 走模块级单例 `resetLiveSession()`：不管 useSessions 是被 App 还是被
   * RecordsPanel 调用的，清的都是同一条路（取消在途请求 + 清事实 + 清字幕）。
   */
  const clearLive = useCallback(() => {
    resetLiveSession();
    useUiStore.getState().setError(null);
  }, []);

  // Debounced auto-save so a record survives switching / restarting a chat.
  useEffect(() => {
    if (!items.length) return;
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      useRecordStore.getState().saveCurrent(
        useConversationStore.getState().items,
        useSettingsStore.getState().settings.targetLanguage,
      );
    }, 800);
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [items]);

  /** Archive the current chat and start a fresh empty one. */
  const newSession = useCallback(() => {
    // 先存档，再清场：顺序反了会把刚清空的列表存进记录里。
    useRecordStore.getState().startNew(
      useConversationStore.getState().items,
      useSettingsStore.getState().settings.targetLanguage,
    );
    clearLive();
    useUiStore.getState().setError(null);
  }, [clearLive]);

  /** Load a saved record back into the live transcript. */
  const openSession = useCallback(
    (id: string) => {
      useRecordStore.getState().saveCurrent(
        useConversationStore.getState().items,
        useSettingsStore.getState().settings.targetLanguage,
      );
      const loaded = useRecordStore.getState().open(id);
      // 旧会话的在途请求必须先掐掉，否则它们会落到刚载入的记录上。
      clearLive();
      useConversationStore.getState().loadItems(loaded);
    },
    [clearLive],
  );

  const removeSession = useCallback(
    (id: string) => {
      useRecordStore.getState().remove(id);
      if (useRecordStore.getState().activeId === null) {
        clearLive();
      }
    },
    [clearLive],
  );

  const clearAllSessions = useCallback(() => {
    useRecordStore.getState().clearAll();
    clearLive();
  }, [clearLive]);

  return { records, activeId, language, newSession, openSession, removeSession, clearAllSessions };
}
