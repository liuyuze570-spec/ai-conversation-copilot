import { useSessions } from '../hooks/useSessions';
import { useRecordStore } from '../stores/records';
import { TARGET_LANGUAGES } from '../../shared/types';

function timeLabel(ms: number): string {
  const date = new Date(ms);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function langLabel(language: string): string {
  return TARGET_LANGUAGES.find((item) => item.value === language)?.label.split(' ')[0] ?? language;
}

export function RecordsPanel({ onClose }: { onClose: () => void }) {
  const { records, activeId, newSession, openSession, removeSession, clearAllSessions } =
    useSessions();
  const setActive = useRecordStore((state) => state.setActive);

  return (
    <div className="subtle-scroll absolute inset-0 z-20 flex flex-col overflow-y-auto bg-ink-900/95 px-3 py-3 backdrop-blur-xl">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-[13px] font-semibold text-white/90">对话记录</span>
        <button
          onClick={onClose}
          className="no-drag rounded-md px-2 py-1 text-[11px] text-white/50 hover:bg-ink-700 hover:text-white"
        >
          返回
        </button>
      </div>

      <button
        onClick={() => {
          newSession();
          onClose();
        }}
        className="no-drag mb-2 w-full rounded-lg bg-accent/85 py-2 text-[12.5px] font-semibold text-white transition hover:bg-accent"
      >
        ＋ 新增对话记录
      </button>

      {records.length === 0 ? (
        <p className="mt-4 text-center text-[11.5px] leading-relaxed text-white/35">
          还没有记录。
          <br />
          点上面「新增对话记录」把当前对话存档，
          <br />
          然后开一段全新的对话。
        </p>
      ) : (
        <div className="space-y-1.5">
          {records.map((record) => {
            const active = record.id === activeId;
            return (
              <div
                key={record.id}
                className={`rounded-xl border px-2.5 py-2 transition ${
                  active
                    ? 'border-accent/45 bg-accent/10'
                    : 'border-line-soft bg-ink-850 hover:border-line-strong'
                }`}
              >
                <button
                  onClick={() => {
                    openSession(record.id);
                    onClose();
                  }}
                  className="no-drag w-full text-left"
                >
                  <div className="flex items-center gap-1.5">
                    <span className="min-w-0 flex-1 truncate text-[12px] text-white/85">
                      {record.title}
                    </span>
                    {active && (
                      <span className="shrink-0 rounded bg-accent/25 px-1 text-[9.5px] text-accent-soft">
                        当前
                      </span>
                    )}
                  </div>
                  <div className="mt-0.5 flex items-center gap-1.5 text-[10px] text-white/35">
                    <span>{timeLabel(record.updatedAt)}</span>
                    <span>·</span>
                    <span>{langLabel(record.language)}</span>
                    <span>·</span>
                    <span>{record.items.length} 条</span>
                  </div>
                </button>
                {!active && (
                  <button
                    onClick={() => {
                      removeSession(record.id);
                      setActive(null);
                    }}
                    className="no-drag mt-1 text-[10px] text-white/30 hover:text-danger/85"
                  >
                    删除
                  </button>
                )}
              </div>
            );
          })}

          <button
            onClick={clearAllSessions}
            className="no-drag mt-2 w-full rounded-md border border-line px-2 py-1 text-[11px] text-white/50 hover:bg-ink-700 hover:text-white"
          >
            清空全部记录
          </button>
        </div>
      )}

      <p className="mt-3 text-center text-[10px] leading-relaxed text-white/25">
        记录只保存在内存中，关闭软件即消失，不会写入磁盘。
      </p>
    </div>
  );
}
