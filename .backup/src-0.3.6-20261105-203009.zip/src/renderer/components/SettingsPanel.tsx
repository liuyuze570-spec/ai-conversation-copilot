import { useEffect, useState } from 'react';
import { useSettingsStore } from '../stores/settings';
import { useAiStatusStore } from '../stores/ai-status';
import { GeneralSettings } from './settings/GeneralSettings';
import { ApiSettings } from './settings/ApiSettings';
import { PerformanceSettings } from './settings/PerformanceSettings';

type Tab = 'general' | 'api' | 'perf';

const TABS: { id: Tab; label: string; hint: string }[] = [
  { id: 'general', label: '常用功能', hint: '语言 · 场景 · 字幕 · 音频 · 窗口' },
  { id: 'api', label: 'API 功能', hint: '连接国内模型 · 只允许国内' },
  { id: 'perf', label: '性能', hint: '各段耗时 · 瓶颈在哪' },
];

/**
 * 设置面板外壳。
 *
 * 拆成两个标签页是有原因的：原来所有选项堆在一条长长的滚动条里，
 * 想改「音量」得先滑过一堆 Base URL，新手根本找不到哪里填 Key。
 * 现在「常用功能」（跟模型无关的日常开关）和「API 功能」（连模型）
 * 各自独立，找东西不用翻。
 */
export function SettingsPanel({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<Tab>('general');
  const uiMode = useSettingsStore((state) => state.settings.uiMode);
  const keyInfo = useAiStatusStore((state) => state.keyInfo);
  const refreshKeys = useAiStatusStore((state) => state.refreshKeys);

  useEffect(() => {
    void refreshKeys();
  }, [refreshKeys]);

  // 设置内容比较多，打开时临时把窗口放大，关上再还原。
  useEffect(() => {
    window.copilot.resize(520, 720);
    return () => {
      window.copilot.resize(
        uiMode === 'compact' ? 400 : 460,
        uiMode === 'compact' ? 330 : 640,
      );
    };
  }, [uiMode]);

  const apiIssue = !keyInfo?.llm || !keyInfo?.sttReady;

  return (
    <div className="subtle-scroll absolute inset-0 z-20 flex flex-col overflow-y-auto bg-ink-900/[0.97] px-3 pb-3 backdrop-blur-xl">
      {/* 标题吸顶：设置项很长，滚到「窗口」那一段时还得能一眼看到怎么退出。 */}
      <div className="sticky top-0 z-10 -mx-3 mb-2 border-b border-line-soft bg-ink-900/[0.97] px-3 pb-2 pt-3 backdrop-blur-xl">
        <div className="mb-2.5 flex items-center justify-between">
          <span className="text-[13px] font-semibold tracking-[0.01em] text-white/90">设置</span>
          <button
            onClick={onClose}
            className="no-drag rounded-lg px-2 py-1 text-[11px] text-white/50 transition-colors duration-150 hover:bg-ink-700 hover:text-white"
          >
            返回
          </button>
        </div>

        <div data-settings-tabs className="flex gap-1.5">
          {TABS.map((item) => {
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                data-settings-tab={item.id}
                data-active={active ? 'true' : 'false'}
                onClick={() => setTab(item.id)}
                className={`no-drag relative flex-1 rounded-xl border px-2 py-1.5 text-left transition-colors duration-150 ${
                  active
                    ? 'border-accent/35 bg-accent/12'
                    : 'border-line-soft bg-ink-850 hover:bg-ink-800'
                }`}
              >
                <span className="flex items-center gap-1.5">
                  <span
                    className={`text-[12px] font-semibold ${active ? 'text-accent-soft' : 'text-white/70'}`}
                  >
                    {item.label}
                  </span>
                  {item.id === 'api' && apiIssue && (
                    <span className="h-1.5 w-1.5 rounded-full bg-warn" />
                  )}
                </span>
                <span className="mt-0.5 block text-[9.5px] leading-tight text-white/30">
                  {item.hint}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {tab === 'general' && <GeneralSettings />}
      {tab === 'api' && <ApiSettings />}
      {tab === 'perf' && <PerformanceSettings />}

      <p className="mt-3 text-center text-[10px] leading-relaxed text-white/20">
        快捷键：Alt+Space 帮我回复 · Alt+R 我没听清 · Alt+Q 继续话题 · Alt+P 暂停 ·
        Alt+V 看视频模式
      </p>
    </div>
  );
}
