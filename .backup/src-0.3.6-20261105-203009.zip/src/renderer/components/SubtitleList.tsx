import { useEffect, useMemo, useRef, useState } from 'react';
import { useConversationStore } from '../stores/conversation';
import { useSettingsStore } from '../stores/settings';
import { useUiStore } from '../stores/ui';
import { transliterate } from '../../services/pronunciation';
import { translationView } from '../../shared/subtitle-state';
import type { ConversationItem } from '../../shared/types';
import { AudioDiagnostics } from './AudioDiagnostics';
import { IconSpeaker, IconWarn } from './icons';

/**
 * 一行译文。
 *
 * 四种状态各有各的样子：翻译中（灰）、成功（正文）、失败（红 + 重试）、
 * 已停止翻译（灰 + 重试）。以前只有「有文本 / 没文本」两种表现，失败时
 * 永远显示 `…`，用户分不清是在翻还是已经死了。
 */
function TranslationLine({
  item,
  fontSize,
  onRetry,
}: {
  item: ConversationItem;
  fontSize: number;
  onRetry: () => void;
}) {
  const view = translationView(item);
  if (view.state === 'ok') {
    return (
      <p className="mt-1 leading-snug text-white/45" style={{ fontSize: `${fontSize}px` }}>
        {item.translatedText}
      </p>
    );
  }
  if (!view.placeholder) return null;
  const failed = view.state === 'failed';
  return (
    <p
      data-translation-state={view.state}
      className={`mt-1 flex items-center gap-1.5 leading-snug ${
        failed ? 'text-danger/85' : 'text-white/35'
      }`}
      style={{ fontSize: `${fontSize}px` }}
    >
      <span>{view.placeholder}</span>
      {view.canRetry && (
        <button
          data-translation-retry
          onClick={onRetry}
          aria-label="重新翻译这一句"
          className={`no-drag rounded-md px-1.5 py-[1px] text-[10px] transition-colors ${
            failed
              ? 'bg-danger/15 text-danger/90 hover:bg-danger/25'
              : 'bg-ink-700 text-white/60 hover:bg-ink-600 hover:text-white/85'
          }`}
        >
          重试
        </button>
      )}
    </p>
  );
}

export function SubtitleList({
  recordsCount,
  onNewSession,
  onOpenRecords,
  onListen,
  onSpeak,
  onRetryTranslate,
  highlightId,
  onHighlightHandled,
}: {
  recordsCount: number;
  onNewSession: () => void;
  onOpenRecords: () => void;
  onListen: () => void;
  /** 朗读某条字幕（学语言时最常用的动作：跟着念一遍）。 */
  onSpeak: (text: string, id: string) => void;
  /** 重新翻译某一句（翻译失败 / 中途停止之后的补救）。 */
  onRetryTranslate: (id: string) => void;
  /** 从「重点信息」点过来时要定位到的那句字幕。 */
  highlightId?: string | null;
  onHighlightHandled?: () => void;
}) {
  const items = useConversationStore((state) => state.items);
  const roundIndex = useConversationStore((state) => state.roundIndex);
  const clear = useConversationStore((state) => state.clear);
  const subtitle = useSettingsStore((state) => state.settings.subtitle);
  const pronunciation = useSettingsStore((state) => state.settings.pronunciation);
  const targetLanguage = useSettingsStore((state) => state.settings.targetLanguage);
  const speakingId = useUiStore((state) => state.speakingId);
  const containerRef = useRef<HTMLDivElement>(null);
  const followRef = useRef(true);
  const [atBottom, setAtBottom] = useState(true);

  /**
   * 每句外语原文的中文谐音。
   *
   * 用户反馈「无法显示中文谐音」：以前谐音只出现在 AI 帮回复的卡片上，字幕区
   * 完全没有。看视频 / 做听力时想跟着念一遍却读不出来，所以这里给每条外语
   * 字幕补一行谐音，受设置里同一个开关控制。
   */
  const pronunciationHints = useMemo(() => {
    const map = new Map<string, string>();
    if (!pronunciation.chinesePronunciation) return map;
    for (const item of items) {
      if (item.speaker !== 'foreign' || item.partial) continue;
      const hint = transliterate(item.originalText, targetLanguage);
      if (hint) map.set(item.id, hint);
    }
    return map;
  }, [items, pronunciation.chinesePronunciation, targetLanguage]);

  // Scroll freely: auto-follow only while the user stays near the bottom.
  useEffect(() => {
    const el = containerRef.current;
    if (!el || !followRef.current) return;
    el.scrollTop = el.scrollHeight;
  }, [items]);

  /*
   * 从「重点信息」点过来：滚到那句话 + 高亮 1.6 秒。
   *
   * 注意这里要临时关掉「自动跟随底部」—— 否则刚滚上去，下一条字幕一来又被
   * 拉回底部，用户根本看不到自己点的那句。
   */
  useEffect(() => {
    if (!highlightId) return;
    const container = containerRef.current;
    if (!container) return;
    const target = container.querySelector<HTMLElement>(
      `[data-subtitle-id="${highlightId}"]`,
    );
    if (!target) return;
    followRef.current = false;
    setAtBottom(false);
    target.scrollIntoView({ block: 'center', behavior: 'smooth' });
    target.dataset.highlight = 'on';
    const timer = setTimeout(() => {
      delete target.dataset.highlight;
      onHighlightHandled?.();
    }, 1600);
    return () => {
      clearTimeout(timer);
      delete target.dataset.highlight;
    };
  }, [highlightId, onHighlightHandled]);

  const handleScroll = () => {
    const el = containerRef.current;
    if (!el) return;
    const distance = el.scrollHeight - el.scrollTop - el.clientHeight;
    const bottom = distance < 48;
    followRef.current = bottom;
    setAtBottom(bottom);
  };

  const jumpToLatest = () => {
    const el = containerRef.current;
    if (!el) return;
    followRef.current = true;
    setAtBottom(true);
    el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  };

  if (!items.length) {
    return (
      <div data-subtitle-list className="flex min-h-0 flex-1 flex-col">
        <AudioDiagnostics onListen={onListen} />
        <div className="flex shrink-0 items-center justify-center gap-1.5 pb-2.5">
          <button onClick={onNewSession} className="btn-ghost !py-1 !text-[10.5px]">
            ＋新记录
          </button>
          <button onClick={onOpenRecords} className="btn-ghost !py-1 !text-[10.5px]">
            记录{recordsCount ? ` ${recordsCount}` : ''}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div data-subtitle-list className="relative flex min-h-0 flex-1 flex-col">
      <div className="flex items-center justify-between gap-2 px-3 pb-1 pt-1.5">
        <div className="flex min-w-0 items-center gap-1.5">
          <span className="label truncate !text-white/35">
            对话 {items.length} 条
          </span>
          {roundIndex > 0 && (
            <span
              data-subtitle-round
              className="tnum shrink-0 rounded-full bg-ink-800 px-1.5 py-[1px] text-[9.5px] text-white/45"
            >
              第 {roundIndex} 轮
            </span>
          )}
        </div>
        <div className="flex shrink-0 items-center gap-0.5">
          <button
            onClick={onNewSession}
            title="把当前对话存成一条记录，然后开一段新对话"
            className="rounded-lg px-1.5 py-0.5 text-[10px] text-white/40 transition-colors hover:bg-ink-700 hover:text-white/80"
          >
            ＋新记录
          </button>
          <button
            onClick={onOpenRecords}
            title="查看对话记录"
            className="rounded-lg px-1.5 py-0.5 text-[10px] text-white/40 transition-colors hover:bg-ink-700 hover:text-white/80"
          >
            记录{recordsCount ? ` ${recordsCount}` : ''}
          </button>
          <button
            onClick={clear}
            title="清空当前对话（不影响已保存的记录）"
            className="rounded-lg px-1.5 py-0.5 text-[10px] text-white/30 transition-colors hover:bg-ink-700 hover:text-white/70"
          >
            清空
          </button>
        </div>
      </div>

      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="subtle-scroll min-h-0 flex-1 space-y-2.5 overflow-y-auto px-3 pb-2 pt-1"
      >
        {items.map((item) => {
          const foreign = item.speaker === 'foreign';
          const lowConfidence =
            subtitle.showConfidenceWarning &&
            typeof item.confidence === 'number' &&
            item.confidence < 0.8;
          return (
            <div
              key={item.id}
              data-subtitle-item
              data-subtitle-id={item.id}
              className="group animate-fade-in-up rounded-xl px-2 py-1.5 transition-colors duration-150
                hover:bg-ink-850/70 data-[highlight=on]:bg-accent/12
                data-[highlight=on]:ring-1 data-[highlight=on]:ring-accent/40"
            >
              <div className="mb-1 flex items-center gap-1.5">
                <span
                  className={`chip ${
                    foreign ? 'bg-accent/15 text-accent-soft/90' : 'bg-ok/12 text-ok/90'
                  }`}
                >
                  {foreign ? '对方' : '你'}
                </span>
                {lowConfidence && (
                  <span
                    className="inline-flex items-center gap-1 text-[10px] text-warn/85"
                    title={`识别置信度 ${item.confidence?.toFixed(2)}`}
                  >
                    <IconWarn size={11} /> 可能识别有误
                  </span>
                )}
                {item.partial && <span className="text-[10px] text-white/25">正在识别…</span>}

                {/* 朗读：看视频 / 做听力时想跟着念一遍，鼠标移上来就有。 */}
                {foreign && !item.partial && (
                  <button
                    data-subtitle-speak
                    onClick={() => onSpeak(item.originalText, item.id)}
                    title="朗读这一句"
                    className={`no-drag ml-auto grid h-5 w-5 shrink-0 place-items-center rounded-md
                      transition-colors duration-150 ${
                        speakingId === item.id
                          ? 'bg-accent/25 text-accent-soft'
                          : 'text-white/25 opacity-0 hover:bg-ink-700 hover:text-white group-hover:opacity-100'
                      }`}
                  >
                    <IconSpeaker size={12} />
                  </button>
                )}
              </div>

              <p
                className={`leading-snug ${foreign ? 'text-white/[0.95]' : 'text-white/60'}`}
                style={{ fontSize: `${subtitle.fontSize}px` }}
              >
                {item.originalText}
              </p>

              {subtitle.showTranslation && foreign && (
                <TranslationLine
                  item={item}
                  fontSize={Math.max(11, subtitle.fontSize - 2)}
                  onRetry={() => onRetryTranslate(item.id)}
                />
              )}

              {pronunciationHints.get(item.id) && (
                <p
                  data-subtitle-pron
                  className="mt-1 text-[10.5px] leading-snug tracking-[0.02em] text-accent-soft/60"
                  style={{ fontSize: `${Math.max(10, subtitle.fontSize - 3)}px` }}
                >
                  {pronunciationHints.get(item.id)}
                </p>
              )}

              {item.correction && (
                <p className="mt-1.5 rounded-lg bg-ok/[0.08] px-2 py-1 text-[11px] text-ok/90">
                  更自然：{item.correction}
                  {item.correctionNote ? `（${item.correctionNote}）` : ''}
                </p>
              )}
            </div>
          );
        })}
      </div>

      {!atBottom && (
        <button
          onClick={jumpToLatest}
          className="no-drag absolute bottom-2.5 left-1/2 -translate-x-1/2 rounded-full border border-line
            bg-ink-800/95 px-3 py-1 text-[11px] text-white/75 shadow-lift backdrop-blur
            transition-colors hover:bg-ink-700"
        >
          ↓ 回到最新
        </button>
      )}
    </div>
  );
}
