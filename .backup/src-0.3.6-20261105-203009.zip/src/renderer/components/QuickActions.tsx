import { useState } from 'react';
import { useSettingsStore } from '../stores/settings';
import { TONE_LABELS, TONE_ORDER } from '../../services/tone';
import { SCENARIO_MODES, type ScenarioMode, type ToneKey } from '../../shared/types';
import type { CopilotMode } from '../hooks/useCopilot';

interface Props {
  disabled: boolean;
  hasSuggestions: boolean;
  scenario: ScenarioMode;
  playback: 'playing' | 'paused';
  onSubmit: (chinese: string) => void;
  onAction: (mode: CopilotMode) => void;
  onCloseReplies: () => void;
  onDemoLine: () => void;
  onSetScenario: (mode: ScenarioMode) => void;
  onPauseReply: () => void;
  onResume: () => void;
  /** Leave demo mode and start capturing the real system output. */
  onListenSystem: () => void;
}

export function QuickActions({
  disabled,
  hasSuggestions,
  scenario,
  playback,
  onSubmit,
  onAction,
  onCloseReplies,
  onDemoLine,
  onSetScenario,
  onPauseReply,
  onResume,
  onListenSystem,
}: Props) {
  const [value, setValue] = useState('');
  const tone = useSettingsStore((state) => state.settings.tone);
  const mockMode = useSettingsStore((state) => state.settings.mockMode);
  const demoAutoPlay = useSettingsStore((state) => state.settings.demoAutoPlay);
  const pauseDetectMs = useSettingsStore((state) => state.settings.pauseDetectMs);
  const update = useSettingsStore((state) => state.update);

  const setTone = (next: ToneKey) => void update({ tone: next });
  const active = SCENARIO_MODES.find((mode) => mode.value === scenario);
  const watching = scenario !== 'conversation';
  const paused = playback === 'paused';

  const primaryLabel = paused
    ? '▶ 继续播放'
    : scenario === 'exam'
      ? '暂停 · 给参考答案'
      : '暂停 · 生成回复';

  return (
    /* shrink-0：主按钮永远不能被挤走 —— 窗口只有 640 高，展开事实卡 + 打开回复
         面板时宁可让上面两块让位，也不能让「暂停 / 帮我回复」掉出屏幕。 */
    <div data-quick-actions className="shrink-0 space-y-2.5 border-t border-line-soft px-3.5 py-3">
      {/* Demo mode is the #1 reason people think the app is broken: it looks
          like it is listening but it can never hear the computer. */}
      {mockMode && (
        <div
          data-demo-banner
          className="flex items-center justify-between gap-2 rounded-2xl border border-warn/15 bg-warn/[0.05] px-2.5 py-2"
        >
          <span className="min-w-0 text-[10.5px] leading-snug text-warn/80">
            演示模式：听不到电脑里的声音
          </span>
          <button
            onClick={onListenSystem}
            className="no-drag shrink-0 rounded-lg border border-warn/35 bg-warn/12 px-2 py-1
              text-[10.5px] font-semibold text-warn transition-colors duration-150 hover:bg-warn/20"
          >
            监听系统声音
          </button>
        </div>
      )}

      {/* Scenario picker: what are we listening to right now? */}
      <div className="flex items-center gap-2">
        <span className="label shrink-0">场景</span>
        <div className="flex min-w-0 items-center gap-0.5 rounded-full bg-ink-850 p-[3px]">
          {SCENARIO_MODES.map((mode) => (
            <button
              key={mode.value}
              onClick={() => onSetScenario(mode.value)}
              title={mode.hint}
              aria-pressed={scenario === mode.value}
              aria-label={`场景：${mode.short}`}
              className={`seg ${scenario === mode.value ? 'seg-on' : ''}`}
            >
              {mode.short}
            </button>
          ))}
        </div>
      </div>

      {watching && (
        <p className="text-[10px] leading-relaxed text-white/30">
          {active?.hint}
          <span className="ml-1 text-white/20">
            （对方停顿 {Math.round(pauseDetectMs / 1000)}s 会自动生成回复）
          </span>
        </p>
      )}

      {/* 快捷动作：回答「这句我该怎么接」。 */}
      <div className="flex flex-wrap gap-1.5">
        <ChipButton disabled={disabled} onClick={() => onAction('didnt-catch')}>
          我没听清
        </ChipButton>
        <ChipButton disabled={disabled} onClick={() => onAction('continue')}>
          继续话题
        </ChipButton>
        <ChipButton disabled={disabled} onClick={() => onAction('simplify')}>
          简单一点
        </ChipButton>
        <ChipButton disabled={disabled} onClick={() => onAction('rephrase')}>
          换一种说法
        </ChipButton>
        <ChipButton disabled={disabled} onClick={() => onAction('natural')}>
          更自然
        </ChipButton>
        {mockMode && (
          <ChipButton onClick={onDemoLine} title="手动来一句示例对话">
            说一句示例
          </ChipButton>
        )}
      </div>

      {/* Sample-chat switch: off by default so nothing pops up on its own. */}
      {mockMode && (
        <div className="flex items-center justify-between rounded-xl border border-line-soft bg-ink-850 px-2.5 py-1.5">
          <span className="text-[10.5px] text-white/45">
            自动播放示例对话
            <span className={`ml-1.5 ${demoAutoPlay ? 'text-ok/80' : 'text-white/25'}`}>
              {demoAutoPlay ? '开' : '关'}
            </span>
          </span>
          <button
            onClick={() => void update({ demoAutoPlay: !demoAutoPlay })}
            className="no-drag text-[10.5px] font-medium text-accent-soft/75 transition-colors hover:text-accent-soft"
          >
            {demoAutoPlay ? '关掉' : '打开'}
          </button>
        </div>
      )}

      {/* Tone / emotion picker — decides HOW the reply sounds. */}
      <div className="flex items-center gap-2">
        <span className="label shrink-0">语气</span>
        <div className="subtle-scroll fade-r -mx-1 flex min-w-0 items-center gap-0.5 overflow-x-auto px-1">
          {TONE_ORDER.map((key) => (
            <button
              key={key}
              onClick={() => setTone(key)}
              aria-pressed={tone === key}
              aria-label={`语气：${TONE_LABELS[key]}`}
              className={`seg ${tone === key ? 'seg-on' : ''}`}
            >
              {TONE_LABELS[key]}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-1.5">
        <input
          value={value}
          onChange={(event) => setValue(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === 'Enter' && value.trim()) {
              onSubmit(value.trim());
              setValue('');
            }
          }}
          placeholder="输入你想说的中文……"
          className="no-drag min-w-0 flex-1 rounded-xl border border-line-soft bg-ink-850 px-2.5 py-2
            text-[12px] text-white/90 placeholder:text-white/25 transition-colors duration-150
            focus:border-accent/45 focus:outline-none"
        />
        <button
          disabled={disabled || !value.trim()}
          onClick={() => {
            onSubmit(value.trim());
            setValue('');
          }}
          className="no-drag shrink-0 rounded-xl border border-line px-2.5 py-2 text-[12px]
            text-white/65 transition-colors duration-150 hover:bg-ink-800 hover:text-white
            disabled:opacity-30"
        >
          转成外语
        </button>
      </div>

      <div className="flex items-center gap-1.5">
        {watching ? (
          <button
            data-primary-action={paused ? 'resume' : 'pause'}
            onClick={paused ? onResume : onPauseReply}
            className={`no-drag flex-1 rounded-xl py-2.5 text-[13px] font-semibold transition-colors
              duration-150 ${
                paused
                  ? 'border border-line bg-ink-800 text-white/85 hover:bg-ink-700'
                  : 'bg-accent text-white hover:bg-accent-dim'
              }`}
          >
            {primaryLabel}
            {!paused && (
              <span className="text-[11px] font-normal opacity-60">　Alt + Space</span>
            )}
          </button>
        ) : (
          <button
            data-primary-action="reply"
            disabled={disabled}
            onClick={() => onAction('reply')}
            className="no-drag flex-1 rounded-xl bg-accent py-2.5 text-[13px] font-semibold
              text-white transition-colors duration-150 hover:bg-accent-dim disabled:opacity-35"
          >
            帮我回复　<span className="text-[11px] font-normal opacity-60">Alt + Space</span>
          </button>
        )}
        {hasSuggestions && (
          <button
            onClick={onCloseReplies}
            title="关闭 AI 帮回复（Alt + X）"
            className="no-drag shrink-0 rounded-xl border border-line px-2.5 py-2.5 text-[12px]
              text-white/55 transition-colors duration-150 hover:border-danger/40
              hover:bg-danger/12 hover:text-danger"
          >
            关闭
          </button>
        )}
      </div>
    </div>
  );
}

function ChipButton({
  children,
  onClick,
  disabled,
  title,
}: {
  children: React.ReactNode;
  onClick: () => void;
  disabled?: boolean;
  title?: string;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      className="no-drag rounded-xl border border-line-soft bg-ink-850 px-2 py-1 text-[11.5px]
        text-white/60 transition-colors duration-150 hover:border-line hover:bg-ink-800
        hover:text-white disabled:opacity-30"
    >
      {children}
    </button>
  );
}
