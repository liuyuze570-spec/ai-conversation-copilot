import { IconClose, IconLock, IconMinus, IconPause, IconPlay, IconSettings, IconWave } from './icons';
import type { ListeningStatus } from '../../shared/types';

interface Props {
  status: ListeningStatus;
  statusMessage: string;
  alwaysOnTop: boolean;
  locked: boolean;
  onToggleListening: () => void;
  onToggleSettings: () => void;
  onToggleAlwaysOnTop: () => void;
  onToggleLock: () => void;
}

const STATUS_TEXT: Record<ListeningStatus, string> = {
  idle: '待机',
  listening: '正在听',
  paused: '已暂停',
  'no-audio': '没有声音进来',
  offline: '离线',
  error: '出错了',
};

/** 状态点的颜色走语义令牌，不再到处写 emerald/amber/rose。 */
const STATUS_DOT: Record<ListeningStatus, string> = {
  idle: 'bg-white/30',
  listening: 'bg-ok',
  paused: 'bg-warn',
  'no-audio': 'bg-warn',
  offline: 'bg-danger',
  error: 'bg-danger',
};

export function TitleBar({
  status,
  statusMessage,
  alwaysOnTop,
  locked,
  onToggleListening,
  onToggleSettings,
  onToggleAlwaysOnTop,
  onToggleLock,
}: Props) {
  const listening = status === 'listening';

  return (
    <div className="drag-region flex items-center gap-2.5 border-b border-line-soft px-3 py-2.5">
      {/* 品牌标记：一个克制的方块 + 声波，比放整行大字更有「产品感」。 */}
      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-accent/15 text-accent-soft">
        <IconWave size={13} />
      </span>

      <div className="flex min-w-0 flex-1 flex-col justify-center leading-tight">
        <span className="truncate text-[12.5px] font-semibold tracking-[0.01em] text-white/90">
          AI Conversation Copilot
        </span>
        <span className="flex min-w-0 items-center gap-1.5" title={statusMessage}>
          <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${STATUS_DOT[status]}`} />
          <span
            className={`truncate text-[10.5px] ${
              status === 'error' ? 'text-danger/90' : 'text-white/40'
            }`}
          >
            {statusMessage || STATUS_TEXT[status]}
          </span>
        </span>
      </div>

      {/* 正在听的时候左侧那条会呼吸，让「它在工作」变得可见。 */}
      {listening && (
        <span className="flex h-3.5 shrink-0 items-center gap-[2px]" aria-hidden>
          {[0, 1, 2].map((index) => (
            <span
              key={index}
              className="w-[2px] origin-center animate-breathe rounded-full bg-accent-soft/80"
              style={{ height: '100%', animationDelay: `${index * 160}ms` }}
            />
          ))}
        </span>
      )}

      <div className="no-drag flex shrink-0 items-center gap-0.5">
        <IconButton
          title={listening ? '暂停监听 (Alt+P)' : '开始监听 (Alt+P)'}
          onClick={onToggleListening}
          tone={listening ? 'accent' : 'default'}
        >
          {listening ? <IconPause /> : <IconPlay size={12} />}
        </IconButton>
        <span className="mx-0.5 h-3.5 w-px bg-line-soft" />
        <IconButton title="置顶" onClick={onToggleAlwaysOnTop} active={alwaysOnTop}>
          <span className="text-[11px] font-bold">T</span>
        </IconButton>
        <IconButton title="锁定位置" onClick={onToggleLock} active={locked}>
          <IconLock />
        </IconButton>
        <IconButton title="设置" onClick={onToggleSettings}>
          <IconSettings />
        </IconButton>
        <IconButton title="最小化" onClick={() => window.copilot.minimize()}>
          <IconMinus />
        </IconButton>
        <IconButton
          title="关闭"
          danger
          onClick={() => {
            window.copilot.setOpacity(1);
            window.copilot.close();
          }}
        >
          <IconClose />
        </IconButton>
      </div>
    </div>
  );
}

function IconButton({
  children,
  title,
  onClick,
  active,
  danger,
  tone = 'default',
}: {
  children: React.ReactNode;
  title: string;
  onClick: () => void;
  active?: boolean;
  danger?: boolean;
  tone?: 'default' | 'accent';
}) {
  return (
    <button
      title={title}
      onClick={onClick}
      className={`no-drag grid h-6 w-6 place-items-center rounded-lg transition-colors duration-150
        ${active ? 'bg-accent/20 text-accent-soft' : ''}
        ${
          tone === 'accent' && !active
            ? 'text-accent-soft/85 hover:bg-accent/15 hover:text-accent-soft'
            : ''
        }
        ${tone === 'default' && !active ? 'text-white/50 hover:bg-ink-700 hover:text-white' : ''}
        ${active ? 'hover:bg-accent/25' : ''}
        ${danger ? 'hover:bg-danger/20 hover:text-danger' : ''}`}
    >
      {children}
    </button>
  );
}
