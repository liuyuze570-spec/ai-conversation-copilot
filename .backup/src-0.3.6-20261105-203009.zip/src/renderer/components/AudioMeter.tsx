import { useEffect, useState } from 'react';
import { useSettingsStore } from '../stores/settings';
import { useUiStore } from '../stores/ui';

const SEGMENTS = 20;

/** -60 dBFS .. 0 dBFS mapped to 0..1 — matches how meters usually read. */
function normalise(db: number): number {
  return Math.max(0, Math.min(1, (db + 60) / 60));
}

/**
 * 分段配色：安静时只亮绿灯，接近削顶才转琥珀 / 玫红。
 * 用语义令牌而不是写死的 emerald/amber/rose，换色时只改一处。
 */
function segmentColor(index: number): string {
  const ratio = index / SEGMENTS;
  if (ratio > 0.9) return 'bg-danger/85';
  if (ratio > 0.72) return 'bg-warn/80';
  return 'bg-ok/80';
}

/**
 * Live input meter.
 *
 * The single biggest complaint was "it stays empty while a movie is playing".
 * Whatever the cause — demo mode, muted output, wrong device, dead sidecar —
 * this bar makes it obvious in one glance whether the computer's sound is
 * actually reaching the app.
 */
export function AudioMeter() {
  const level = useUiStore((state) => state.level);
  // 只开麦克风（没开系统声音）时，标签要如实显示「麦克风」。
  // 必须放在下面几个 early return 之前，否则违反 hooks 规则。
  const captureMicOnly = useSettingsStore(
    (state) =>
      state.settings.audio.captureMicrophone && !state.settings.audio.captureSystemAudio,
  );
  const status = useUiStore((state) => state.status);
  const mockMode = useSettingsStore((state) => state.settings.mockMode);

  const [stale, setStale] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setStale(Date.now() - useUiStore.getState().levelAt > 2500);
    }, 700);
    return () => clearInterval(timer);
  }, []);

  // Demo mode never touches the sound device, so there is nothing to show.
  if (mockMode) return null;
  if (status === 'idle') return null;

  const db = level?.db ?? -120;
  const active = level ? Math.round(normalise(db) * SEGMENTS) : 0;
  /*
   * 还没收到第一个电平包时，退回「设置里实际开着的采集源」。
   *
   * 旧写法在 `level` 为空时无条件显示「系统声音」，于是只开麦克风的用户会
   * 看到「系统声音」三个字，以为软件抓错了设备。收到电平之后以实际来源为准。
   */
  const source = level
    ? level.source === 'mic'
      ? '麦克风'
      : '系统声音'
    : captureMicOnly
      ? '麦克风'
      : '系统声音';
  const live = Boolean(level) && !stale;

  return (
    <div
      data-audio-meter
      data-audio-live={live ? 'true' : 'false'}
      data-audio-db={String(db)}
      className="flex items-center gap-2.5 border-b border-line-soft px-3 py-[6px]"
    >
      <span
        className={`h-1.5 w-1.5 shrink-0 rounded-full transition-colors duration-200 ${
          live && level?.speaking ? 'bg-ok' : live ? 'bg-ok/45' : 'bg-white/20'
        }`}
      />

      <span className="label shrink-0 !text-white/45">{source}</span>

      <div className="flex h-[7px] min-w-0 flex-1 items-end gap-[2px]">
        {Array.from({ length: SEGMENTS }).map((_, index) => (
          <span
            key={index}
            className={`h-full flex-1 rounded-full transition-[background-color,opacity] duration-75 ${
              index < active ? segmentColor(index) : 'bg-ink-700'
            }`}
          />
        ))}
      </div>

      <span className="tnum w-[64px] shrink-0 text-right font-mono text-[10px] text-white/30">
        {live
          ? `${level?.capturedSeconds.toFixed(0) ?? 0}s · ${db > -95 ? `${db.toFixed(0)}dB` : '静音'}`
          : status === 'listening'
            ? '无信号'
            : '已停止'}
      </span>
    </div>
  );
}
