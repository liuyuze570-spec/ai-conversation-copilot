import { useState } from 'react';
import { useSettingsStore } from '../../stores/settings';
import { TONE_LABELS, TONE_ORDER } from '../../../services/tone';
import type { Settings } from '../../../shared/types';
import {
  SCENARIO_MODES,
  NATIVE_LANGUAGES,
  REPLY_STYLES,
  RESPONSE_LENGTHS,
  TARGET_LANGUAGES,
} from '../../../shared/types';
import { levelFor, levelsFor } from '../../../shared/levels';
import type { HealthReport } from '../../../shared/health';
import { HealthView } from '../HealthView';
import {
  Button,
  DeviceSelect,
  Hint,
  Range,
  Row,
  Section,
  Select,
  TextInput,
  Toggle,
} from './controls';

/**
 * 「常用功能」标签页：跟模型 / Key 无关的所有日常开关。
 * 界面语言、场景、发音、字幕、窗口、音频设备、个人资料。
 */
export function GeneralSettings() {
  const settings = useSettingsStore((state) => state.settings);
  const update = useSettingsStore((state) => state.update);
  const [checking, setChecking] = useState(false);
  const [health, setHealth] = useState<HealthReport | null>(null);

  const patch = (value: Partial<Settings>) => void update(value);

  const targetLabel =
    TARGET_LANGUAGES.find((item) => item.value === settings.targetLanguage)?.label ?? '英语 English';
  const targetShort = targetLabel.split(' ')[0];
  const currentLevel = levelFor(settings.languageLevels, settings.targetLanguage);

  const runCheck = async () => {
    setChecking(true);
    try {
      setHealth(await window.copilot.systemCheck());
    } finally {
      setChecking(false);
    }
  };

  return (
    <>
      <Section title="语言">
        <Row label="母语">
          <Select
            value={settings.nativeLanguage}
            options={NATIVE_LANGUAGES}
            dataAttr="data-native-select"
            onChange={(value) => patch({ nativeLanguage: value })}
          />
        </Row>
        <Row label="对话语言">
          <Select
            value={settings.targetLanguage}
            options={TARGET_LANGUAGES.map((item) => ({ value: item.value, label: item.label }))}
            dataAttr="data-target-select"
            onChange={(value) => patch({ targetLanguage: value as Settings['targetLanguage'] })}
          />
        </Row>
        <Hint>
          母语 = 翻译成哪种语言给你看（默认中文）；对话语言 = 你要跟对方说哪种话（默认英语）。
          换了对话语言，下面的「语言水平」会换成那门语言自己的等级。
        </Hint>
        <Row label={`语言水平（${targetShort}）`}>
          <Select
            value={currentLevel}
            options={levelsFor(settings.targetLanguage)}
            dataAttr="data-grade-select"
            onChange={(value) =>
              patch({
                // 每门语言各存一份：从日语切回英语，英语还是你原来选的那档。
                languageLevels: { ...settings.languageLevels, [settings.targetLanguage]: value },
              })
            }
          />
        </Row>
        <Hint>
          英语是「B 级 → 专业八级」，俄语是「入门 → 专业八级」，日语是 JLPT N5 → N1，韩语是
          TOPIK 1 → 6 级。AI 会照这个水平挑词：等级越低越好念，越高越地道。
        </Hint>
        <Row label="回复长度">
          <Select
            value={settings.responseLength}
            options={RESPONSE_LENGTHS}
            dataAttr="data-length-select"
            onChange={(value) => patch({ responseLength: value as Settings['responseLength'] })}
          />
        </Row>
        <Row label="回复风格">
          <Select
            value={settings.replyStyle}
            options={REPLY_STYLES}
            dataAttr="data-reply-style"
            onChange={(value) => patch({ replyStyle: value as Settings['replyStyle'] })}
          />
        </Row>
        <Hint>
          回复风格决定 AI 帮你想的那句话怎么说。选「幽默」会轻松开玩笑，「正式」适合面试 / 商务，
          「简单」用最好念的词。选完之后 AI 必须按这个风格写，不会自己换一种；换完下一句回复立刻生效。
        </Hint>
        <Row label="语气 / 情绪">
          <Select
            value={settings.tone}
            options={TONE_ORDER.map((key) => ({ value: key, label: TONE_LABELS[key] }))}
            onChange={(value) => patch({ tone: value as Settings['tone'] })}
          />
        </Row>
        <Hint dataAttr="data-tone-hint">
          选了具体情绪（开心 / 难过 / 期待…），三条回复都必须按这个情绪说，不会被对话内容带偏；
          选「自动」时由 AI 看对方最后说的话判断，对方开心它就开心，对方低落它就轻声些。
          强烈情绪只针对事情，不针对人，也不会出现脏话与侮辱。
        </Hint>
      </Section>

      <Section title="场景">
        <Row label="当前场景">
          <Select
            value={settings.scenarioMode}
            options={SCENARIO_MODES.map((mode) => ({ value: mode.value, label: mode.label }))}
            onChange={(value) => patch({ scenarioMode: value as Settings['scenarioMode'] })}
          />
        </Row>
        <Hint>{SCENARIO_MODES.find((mode) => mode.value === settings.scenarioMode)?.hint}</Hint>
        <Toggle
          label="停顿自动生成回复"
          value={settings.autoReplyOnPause}
          onChange={(value) => patch({ autoReplyOnPause: value })}
        />
        <Range
          label="停顿判定"
          value={settings.pauseDetectMs}
          min={1000}
          max={6000}
          step={250}
          format={(value) => `${(value / 1000).toFixed(1)}s`}
          onChange={(value) => patch({ pauseDetectMs: value })}
        />
        <Hint>
          看视频 / 四六级听力时：对方说的每一句都会实时翻译；对方停下来（或你暂停视频）
          超过上面的秒数，就自动生成可以回应的内容。
        </Hint>
      </Section>

      <Section title="发音辅助">
        <Toggle
          label="IPA 音标"
          value={settings.pronunciation.ipa}
          onChange={(value) => patch({ pronunciation: { ...settings.pronunciation, ipa: value } })}
        />
        <Toggle
          label="音节拆分"
          value={settings.pronunciation.syllables}
          onChange={(value) =>
            patch({ pronunciation: { ...settings.pronunciation, syllables: value } })
          }
        />
        <Toggle
          label="中文近似音"
          value={settings.pronunciation.chinesePronunciation}
          onChange={(value) =>
            patch({ pronunciation: { ...settings.pronunciation, chinesePronunciation: value } })
          }
        />
        <Hint>中文发音仅为近似辅助，建议以 IPA / 语音朗读为准。</Hint>
      </Section>

      <Section title="字幕">
        <Range
          label="字号"
          value={settings.subtitle.fontSize}
          min={11}
          max={26}
          format={(value) => `${value}px`}
          onChange={(value) => patch({ subtitle: { ...settings.subtitle, fontSize: value } })}
        />
        <Range
          label="可上翻历史"
          value={settings.subtitle.maxItems}
          min={20}
          max={500}
          step={20}
          format={(value) => `${value} 条`}
          onChange={(value) => patch({ subtitle: { ...settings.subtitle, maxItems: value } })}
        />
        <Toggle
          label="显示中文翻译"
          value={settings.subtitle.showTranslation}
          onChange={(value) =>
            patch({ subtitle: { ...settings.subtitle, showTranslation: value } })
          }
        />
        <Toggle
          label="低置信度提示"
          value={settings.subtitle.showConfidenceWarning}
          onChange={(value) =>
            patch({ subtitle: { ...settings.subtitle, showConfidenceWarning: value } })
          }
        />
      </Section>

      <Section title="重点信息">
        <Toggle
          label="提取关键事实"
          value={settings.facts.enabled}
          onChange={(value) => patch({ facts: { ...settings.facts, enabled: value } })}
        />
        <Toggle
          label="用模型补人名、事项"
          value={settings.facts.useModel}
          onChange={(value) => patch({ facts: { ...settings.facts, useModel: value } })}
        />
        <Hint>
          时间、日期、金额、数量在本机用规则认，不联网、不花钱；人名、机构、待办、
          负责人交给你在「API 功能」里选的那家国内服务商。关掉第二项就只保留本地规则。
          这些卡片只存在当前会话的内存里，清空对话或关掉软件就没了。
        </Hint>
      </Section>

      <Section title="窗口">
        <Range
          label="不透明度"
          value={Math.round(settings.window.opacity * 100)}
          min={35}
          max={100}
          format={(value) => `${value}%`}
          onChange={(value) => {
            const opacity = value / 100;
            patch({ window: { ...settings.window, opacity } });
            window.copilot.setOpacity(opacity);
          }}
        />
        <Toggle
          label="始终置顶"
          value={settings.window.alwaysOnTop}
          onChange={(value) => {
            patch({ window: { ...settings.window, alwaysOnTop: value } });
            window.copilot.setAlwaysOnTop(value);
          }}
        />
        <Row label="界面模式">
          <Select
            value={settings.uiMode}
            options={[
              { value: 'compact', label: '紧凑' },
              { value: 'advanced', label: '完整' },
            ]}
            onChange={(value) => patch({ uiMode: value as Settings['uiMode'] })}
          />
        </Row>
        <div className="mt-1">
          <Button full onClick={() => window.copilot.resetWindowPosition()}>
            重置窗口位置（找不到窗口时用）
          </Button>
        </div>
      </Section>

      <Section title="音频（听谁的）">
        <Row label="系统声音设备">
          <DeviceSelect
            kind="system"
            value={settings.audio.systemDeviceId}
            onChange={(value) => patch({ audio: { ...settings.audio, systemDeviceId: value } })}
          />
        </Row>
        <Row label="麦克风设备">
          <DeviceSelect
            kind="mic"
            value={settings.audio.micDeviceId}
            onChange={(value) => patch({ audio: { ...settings.audio, micDeviceId: value } })}
          />
        </Row>
        <Toggle
          label="捕获系统声音（对方）"
          value={settings.audio.captureSystemAudio}
          onChange={(value) => patch({ audio: { ...settings.audio, captureSystemAudio: value } })}
        />
        <Toggle
          label="捕获麦克风（自己）"
          value={settings.audio.captureMicrophone}
          onChange={(value) => patch({ audio: { ...settings.audio, captureMicrophone: value } })}
        />
        <Toggle
          label="口语纠错提示"
          value={settings.speakingCorrection}
          onChange={(value) => patch({ speakingCorrection: value })}
        />
        <Range
          label="静音判定"
          value={settings.audio.vadSilenceMs}
          min={300}
          max={2200}
          step={100}
          format={(value) => `${value}ms`}
          onChange={(value) => patch({ audio: { ...settings.audio, vadSilenceMs: value } })}
        />
        <Hint>
          停顿超过这个时长就算「一句话说完了」，送去识别一次。字幕被切得太碎、
          翻译跟不上时，把它往大调（1200–1600ms）；想更快出字幕就往小调。
        </Hint>
        <Range
          label="灵敏度"
          value={settings.audio.sensitivity ?? 1}
          min={1}
          max={4}
          step={0.2}
          format={(value) => `${value.toFixed(1)}x`}
          onChange={(value) => patch({ audio: { ...settings.audio, sensitivity: value } })}
        />
        <Hint>
          电影对白偏轻、笔记本扬声器音量小时，把<strong className="text-white/50">灵敏度</strong>
          调高（2–3x）能明显改善「听得到但识别不出」。增益是自适应的，音量再大也不会削顶失真。
        </Hint>

        <div className="mt-1.5 rounded-lg border border-line-soft bg-ink-850 px-2 py-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] text-white/60">听不到声音？让它自己查一遍</span>
            <Button
              variant="primary"
              disabled={checking}
              dataAttr="data-health-run-settings"
              onClick={() => void runCheck()}
            >
              {checking ? '检查中…' : '一键诊断'}
            </Button>
          </div>
          {/* 没点按钮之前只说会查什么，不摆任何结果 —— 一片全绿的技术参数对用户
              没有意义，只有「哪一项挡着出字幕」才有意义。 */}
          {health ? (
            <div className="mt-1.5">
              <HealthView report={health} />
            </div>
          ) : (
            <Hint>
              会自己检查音频组件、默认扬声器、采集开关、识别 Key 和模型，只把有问题的
              地方列出来。检查期间请让电影 / 音乐正常播放。
            </Hint>
          )}
        </div>
      </Section>

      <Section title="我的资料（可选）">
        <Row label="名字">
          <TextInput
            value={settings.profile.name}
            onChange={(value) => patch({ profile: { ...settings.profile, name: value } })}
          />
        </Row>
        <Row label="城市">
          <TextInput
            value={settings.profile.city}
            onChange={(value) => patch({ profile: { ...settings.profile, city: value } })}
          />
        </Row>
        <Row label="兴趣">
          <TextInput
            value={settings.profile.interests}
            onChange={(value) => patch({ profile: { ...settings.profile, interests: value } })}
          />
        </Row>
        <Hint>填了之后 AI 帮回复会更贴合你的情况（比如提到你所在城市的事）。</Hint>
      </Section>
    </>
  );
}
