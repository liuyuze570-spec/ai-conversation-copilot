import type { SpeakRequest, TTSProvider } from '../types';

/**
 * Zero-config TTS using the OS voices (Windows has en-US voices offline).
 * This is the MVP default: no API key, instant playback.
 *
 * 两个细节是踩过的坑：
 * 1. `speechSynthesis.cancel()` 之后，被取消那条 utterance 的 Promise **永远不会
 *    结束**（既不 onend 也不 onerror）。旧实现就这样把调用方挂在 `await` 上，
 *    切歌 / 点停止之后界面的「正在朗读」图标一直不消。现在 stop() 主动收尾。
 * 2. 连续点两次播放时，旧的那条要先取消再排新的，否则 Windows 上会两条叠着念。
 */
export class WebSpeechTTS implements TTSProvider {
  readonly id = 'web-speech';
  readonly displayName = 'System voice (offline)';

  private voices: SpeechSynthesisVoice[] = [];
  /** 当前这条的 resolver —— stop() 要能把它叫醒。 */
  private pendingResolve: (() => void) | null = null;

  private ensureVoices() {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    if (!this.voices.length) this.voices = window.speechSynthesis.getVoices();
  }

  listVoices(): { name: string; lang: string }[] {
    this.ensureVoices();
    return this.voices.map((voice) => ({ name: voice.name, lang: voice.lang }));
  }

  private pickVoice(preferred?: string, lang = 'en-US'): SpeechSynthesisVoice | undefined {
    this.ensureVoices();
    if (!this.voices.length) return undefined;
    if (preferred) {
      const exact = this.voices.find((voice) => voice.name === preferred);
      if (exact) return exact;
    }
    const wanted = lang.toLowerCase().split('-')[0];
    const matching = this.voices.filter((voice) => voice.lang.toLowerCase().startsWith(wanted));
    return (
      matching.find((voice) => voice.lang.toLowerCase() === lang.toLowerCase()) ??
      matching[0] ??
      this.voices.find((voice) => voice.lang.toLowerCase().startsWith('en')) ??
      this.voices[0]
    );
  }

  speak(request: SpeakRequest): Promise<void> {
    if (typeof window === 'undefined' || !window.speechSynthesis) {
      return Promise.reject(new Error('TTS_NOT_AVAILABLE'));
    }

    const synth = window.speechSynthesis;
    // 先收掉上一句（并把它等着的 Promise 结束掉），再排新的。
    this.stop();

    const lang = request.lang || 'en-US';
    const utterance = new SpeechSynthesisUtterance(request.text);
    utterance.lang = lang;
    // 慢速播放就是靠这一行生效的（系统语音模式）。
    utterance.rate = Math.min(2, Math.max(0.5, request.speed ?? 1));
    utterance.pitch = 1;
    const voice = this.pickVoice(request.voice, lang);
    if (voice) utterance.voice = voice;

    return new Promise<void>((resolve) => {
      const done = () => {
        if (this.pendingResolve === resolve) this.pendingResolve = null;
        resolve();
      };
      this.pendingResolve = resolve;
      utterance.onend = done;
      utterance.onerror = done;
      synth.speak(utterance);
    });
  }

  stop() {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    const resolve = this.pendingResolve;
    this.pendingResolve = null;
    resolve?.();
  }
}
