import type { TranslateRequest, TranslationProvider } from '../types';
import { TRANSLATIONS, WORD_HINTS } from './corpus';

export class MockTranslator implements TranslationProvider {
  readonly id = 'mock';
  readonly displayName = 'Mock Translator (offline)';

  async translate(request: TranslateRequest): Promise<string> {
    await new Promise((resolve) => setTimeout(resolve, 120));
    const exact = TRANSLATIONS[request.text.trim()];
    if (exact) return exact;

    const hits = WORD_HINTS.filter(([pattern]) => pattern.test(request.text)).map(
      ([, zh]) => zh,
    );
    const suffix = /\?$/.test(request.text.trim()) ? '？' : '';
    if (hits.length) return `${hits.join(' / ')}${suffix}`;
    return `（Mock 翻译）${request.text}${suffix}`;
  }
}
