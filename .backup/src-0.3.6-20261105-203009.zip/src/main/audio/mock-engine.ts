import type { BrowserWindow } from 'electron';
import { IPC, type AudioStatusPayload, type TranscriptPayload } from '../../shared/ipc';
import { logger } from '../logger';
import { getSettingsStore } from '../settings-store';
import type { TargetLanguage } from '../../shared/types';
import type { DemoLine } from '../../services/mock/corpus';
import { LANGUAGE_SCENARIOS, SCENARIOS } from '../../services/mock/corpus';

export interface AudioEngine {
  start(): void;
  stop(): void;
}

export type { DemoLine };

/** Backwards-compatible default script (first scenario). */
export const DEMO_SCRIPT: DemoLine[] = SCENARIOS[0].lines;

const WORD_DELAY_MS = 110;
const GAP_MS = 1400;

/**
 * Mock engine: plays a scripted conversation through the exact same
 * transcript pipeline used by the real Windows audio capture, so the whole
 * UI / context / AI flow can be developed and demoed without an API key.
 */
export class MockAudioEngine implements AudioEngine {
  private timer: NodeJS.Timeout | null = null;
  private scenarioIndex = Math.floor(Math.random() * SCENARIOS.length);
  private lineIndex = 0;
  private wordIndex = 0;
  private current: string[] = [];
  private running = false;

  constructor(private readonly win: BrowserWindow) {}

  /** Scenarios for the currently selected target language. */
  private scenarios() {
    const language = getSettingsStore().get().targetLanguage as TargetLanguage;
    return LANGUAGE_SCENARIOS[language] ?? SCENARIOS;
  }

  start() {
    if (this.running) return;
    this.running = true;
    // Be explicit: this mode cannot hear the computer, and users rightly
    // expect subtitles from whatever they are playing.
    this.emitStatus({
      status: 'listening',
      message: '演示模式：只播放内置示例，听不到电脑里的声音（设置里可关闭）',
    });

    const settings = getSettingsStore().get();
    if (!settings.demoAutoPlay) {
      // Sample conversation is opt-in — stay silent until the user turns it on.
      logger.info('Audio', 'mock engine listening (demo auto-play is off)');
      return;
    }

    const list = this.scenarios();
    const scenario = list[this.scenarioIndex % list.length];
    logger.info('Audio', `mock engine started (scenario: ${scenario.name})`);
    this.tick();
  }

  /** Push exactly one demo line, even when auto-play is switched off. */
  sayOnce() {
    const list = this.scenarios();
    const scenario = list[this.scenarioIndex % list.length];
    const line = scenario.lines[this.lineIndex % scenario.lines.length];
    this.lineIndex = (this.lineIndex + 1) % scenario.lines.length;
    // 只记场景名和字数：app.log 里不留对话正文（和真实识别路径保持同一口径）。
    logger.info('Audio', `mock one-shot line (${scenario.name}) chars=${line.english.length}`);
    this.emit({
      speaker: line.speaker,
      text: line.english,
      partial: false,
      confidence: line.confidence,
    });
    return line.english;
  }

  /**
   * 推一句**指定文本**（只给自检用）。
   *
   * 演示语料里几乎没有时间/金额，所以「关键事实确认卡」在演示模式下永远
   * 不会触发 —— 想真实验证那条链路（定稿 → 规则提取 → store → 面板），
   * 就必须能塞一句带事实的话进去。调用方已用 `COPILOT_SELFTEST` 收口。
   */
  sayText(text: string) {
    logger.info('Audio', `mock selftest line chars=${text.length}`);
    this.emit({ speaker: 'foreign', text, partial: false, confidence: 0.95 });
    return text;
  }

  stop() {
    this.running = false;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    logger.info('Audio', 'mock engine stopped');
    this.emitStatus({ status: 'paused' });
  }

  private send(channel: string, payload: unknown) {
    try {
      const win = this.win;
      if (win.isDestroyed() || win.webContents.isDestroyed()) {
        this.running = false;
        return;
      }
      win.webContents.send(channel, payload);
    } catch {
      this.running = false;
    }
  }

  private emitStatus(payload: AudioStatusPayload) {
    this.send(IPC.AUDIO_STATUS, payload);
  }

  private emit(payload: TranscriptPayload) {
    this.send(IPC.AUDIO_TRANSCRIPT, payload);
  }

  private schedule(ms: number) {
    this.timer = setTimeout(() => {
      if (!this.running) return;
      this.tick();
    }, ms);
  }

  private tick() {
    const list = this.scenarios();
    const scenario = list[this.scenarioIndex % list.length];
    const line = scenario.lines[this.lineIndex];
    const words = line.english.split(' ');

    if (this.wordIndex === 0) this.current = [];

    if (this.wordIndex < words.length) {
      this.current.push(words[this.wordIndex]);
      this.wordIndex += 1;
      this.emit({
        speaker: line.speaker,
        text: this.current.join(' '),
        partial: true,
        confidence: line.confidence * 0.8,
      });
      this.schedule(WORD_DELAY_MS);
      return;
    }

    // Finalize the sentence, then move to the next line after a short pause.
    this.emit({
      speaker: line.speaker,
      text: line.english,
      partial: false,
      confidence: line.confidence,
    });
    this.wordIndex = 0;
    this.current = [];
    this.lineIndex += 1;

    // Scenario finished → move to a different one so the demo never gets stale.
    if (this.lineIndex >= scenario.lines.length) {
      this.lineIndex = 0;
      this.scenarioIndex =
        (this.scenarioIndex + 1 + Math.floor(Math.random() * Math.max(1, list.length - 1))) %
        list.length;
      const next = list[this.scenarioIndex];
      logger.info('Audio', `mock scenario → ${next.name}`);
    }
    this.schedule(GAP_MS);
  }
}
