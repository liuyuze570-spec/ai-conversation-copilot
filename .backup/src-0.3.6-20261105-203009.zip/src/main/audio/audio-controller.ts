import { ipcMain, type BrowserWindow } from 'electron';
import { IPC } from '../../shared/ipc';
import { getSettingsStore } from '../settings-store';
import { logger } from '../logger';
import { pipelineSignature, shouldRestartPipeline, type PipelineConfig } from '../../shared/pipeline-gate';
import { MockAudioEngine, type AudioEngine } from './mock-engine';
import { PythonAudioEngine, probeAudio, pythonAvailability, resetPythonDiscovery } from './python-engine';

let engine: AudioEngine | null = null;
let boundWindow: BrowserWindow | null = null;
/**
 * 当前管线的配置指纹（'' = 没有管线在跑）。
 *
 * 启动请求有两个来源：主进程开机自动启动（隐私条款已接受时），以及渲染层
 * 「设置加载完了、状态还是 idle」时的自我启动。两者会在开机那 1 秒内同时发生。
 * 以前这里无条件 `stop → start`，结果是每次开机都白开一个 python 采集进程再把它
 * 杀掉（日志里会看到两条 `loopback stream started`、会话号从 1 跳到 3）。
 * 现在只有「配置真的变了」才重建，重复请求直接忽略。判定逻辑见
 * `shared/pipeline-gate.ts`（纯函数，有单测）。
 */
let runningSignature = '';

function currentConfig(): PipelineConfig {
  const s = getSettingsStore().get();
  return {
    mockMode: s.mockMode,
    captureSystemAudio: s.audio.captureSystemAudio,
    captureMicrophone: s.audio.captureMicrophone,
    systemDeviceId: s.audio.systemDeviceId || 'default',
    micDeviceId: s.audio.micDeviceId || 'default',
    pythonPath: s.audio.pythonPath || '',
    demoAutoPlay: s.demoAutoPlay,
    targetLanguage: s.targetLanguage,
  };
}

export function startAudioPipeline(win: BrowserWindow) {
  const config = currentConfig();
  if (!shouldRestartPipeline(runningSignature, config)) {
    logger.info('Audio', 'start skipped (pipeline already running with same settings)');
    return;
  }
  stopAudioPipeline();
  boundWindow = win;
  if (config.mockMode) {
    engine = new MockAudioEngine(win);
  } else {
    engine = new PythonAudioEngine(win);
  }
  runningSignature = pipelineSignature(config);
  engine.start();
}

export function stopAudioPipeline() {
  if (engine) {
    engine.stop();
    engine = null;
  }
  runningSignature = '';
}

export function isPipelineRunning(): boolean {
  return engine !== null;
}

/** Called by the window layer to release resources on quit. */
export function disposeAudio() {
  try {
    stopAudioPipeline();
    logger.info('Audio', 'pipeline disposed');
  } catch (error) {
    logger.error('Audio', `dispose failed: ${String(error)}`);
  }
}

export function registerAudioIpc(win: BrowserWindow) {
  boundWindow = win;

  ipcMain.handle(IPC.AUDIO_START, async () => {
    try {
      const settings = getSettingsStore().get();
      logger.info(
        'Audio',
        `start requested (mock=${settings.mockMode}, system=${settings.audio.captureSystemAudio}, mic=${settings.audio.captureMicrophone})`,
      );
      startAudioPipeline(win);
      return { ok: true };
    } catch (error) {
      logger.error('Audio', `start failed: ${String(error)}`);
      return { ok: false, message: String(error) };
    }
  });

  ipcMain.handle(IPC.AUDIO_STOP, async () => {
    stopAudioPipeline();
    return { ok: true };
  });

  ipcMain.handle(IPC.AUDIO_DEMO_LINE, async (_event, text?: unknown) => {
    const settings = getSettingsStore().get();
    if (!settings.mockMode) {
      return { ok: false, message: '真实模式下没有示例对话，请先开启演示模式' };
    }
    // Make sure a mock engine exists even while auto-play is switched off.
    if (!engine || !(engine instanceof MockAudioEngine)) {
      stopAudioPipeline();
      engine = new MockAudioEngine(win);
      runningSignature = pipelineSignature(currentConfig());
      engine.start();
    }
    /*
     * 指定文本只给自检用（COPILOT_SELFTEST=1）。不设这个开关时行为完全不变，
     * 仍然从内置语料里取一句 —— 免得界面上的「说一句示例」变成任意文本注入口。
     */
    if (typeof text === 'string' && text.trim() && process.env.COPILOT_SELFTEST === '1') {
      const said = (engine as MockAudioEngine).sayText(text.trim());
      return { ok: true, text: said };
    }
    const said = (engine as MockAudioEngine).sayOnce();
    return { ok: true, text: said };
  });

  ipcMain.handle(IPC.AUDIO_DEVICES, async () => {
    const settings = getSettingsStore().get();
    if (settings.mockMode) {
      return [
        { id: 'mock-system', name: '系统音频（演示）', kind: 'system' as const },
        { id: 'mock-mic', name: '麦克风（演示）', kind: 'mic' as const },
      ];
    }
    try {
      return await new PythonAudioEngine(win).listDevices();
    } catch (error) {
      logger.warn('Audio', `device enumeration failed: ${String(error)}`);
      return [];
    }
  });

  /**
   * Record a few seconds and report the real level. This is the answer to
   * "why is the subtitle list empty?" — it separates capture from recognition.
   * Also re-resolves Python so filling in a path takes effect immediately.
   */
  ipcMain.handle(IPC.AUDIO_PROBE, async (_event, mode: 'loopback' | 'mic' = 'loopback') => {
    resetPythonDiscovery();
    const availability = pythonAvailability();
    if (!availability.available) {
      return {
        ok: false,
        mode,
        device: '',
        deviceId: '',
        rate: 0,
        channels: 0,
        rms: 0,
        peak: 0,
        db: -120,
        durationMs: 0,
        hasSignal: false,
        message:
          '安装包自带的音频组件没找到（可能被杀毒软件拦截，或安装不完整）。建议重新安装本软件；也可以在设置 → 音频里手动指定 python.exe 的路径。',
      };
    }
    return probeAudio(mode, 2.5);
  });
}

export function getBoundWindow(): BrowserWindow | null {
  return boundWindow;
}
