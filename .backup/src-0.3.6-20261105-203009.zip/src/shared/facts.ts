/**
 * 「关键事实确认卡」的纯逻辑层。
 *
 * 目标：从实时双语对话里抓住**说清楚了的事实**（时间、地点、金额、事项…），
 * 让用户当场核对，而不是事后靠回忆。
 *
 * ## 三条硬规则（都是审计里明确要求的）
 *
 * 1. **只忠实转写，不许升格**。原话说「可能周五」，这里就必须还带着
 *    `certainty: 'uncertain'`，界面上标「待核对」；绝不能让模型把它写成
 *    「确定周五」。原话说「不是三点，是四点」，那是**更正**，取更正后的值。
 * 2. **原文片段必须真的能在字幕里找到**。所有产出都过 `validateFacts()`，
 *    对不上的整条丢弃 —— 宁可少一张卡，也不能给用户看一句他没听过的「原话」。
 * 3. **不编造置信度**。有疑问就写「待核对」，不显示任何百分比。
 *
 * ## 为什么时间/金额先用规则
 *
 * 数字是最容易规则化的，也是最不能再问一次模型的：一句话里有没有「三点」
 * 用正则就知道，没必要为它付一次延迟和费用。规则先跑，模型只补规则做不了的
 * （人名、组织、事项、负责人）。
 */

export const FACT_KINDS = [
  'time',
  'date',
  'place',
  'money',
  'quantity',
  'person',
  'org',
  'task',
  'owner',
] as const;

export type FactKind = (typeof FACT_KINDS)[number];

/** 界面上的中文短标签（用户要求「简短中文标签配合外语原文」）。 */
export const FACT_LABELS: Record<FactKind, string> = {
  time: '时间',
  date: '日期',
  place: '地点',
  money: '金额',
  quantity: '数量',
  person: '人名',
  org: '机构',
  task: '事项',
  owner: '负责人',
};

export type FactCertainty = 'stated' | 'uncertain' | 'corrected';
export type FactStatus = 'pending' | 'confirmed';

export interface FactItem {
  id: string;
  kind: FactKind;
  /** 事实内容（中文短句，例如「明天下午三点」）。用户可改。 */
  value: string;
  /** 原话片段，**必须**是对应字幕的子串。 */
  sourceText: string;
  /** 片段取自哪个字段：原话还是译文。 */
  sourceField: 'original' | 'translation';
  /** 来源字幕 id（点击定位用）。 */
  itemId: string;
  /** 来源字幕是第几轮（排序 + 展示）。 */
  roundIndex: number;
  certainty: FactCertainty;
  status: FactStatus;
  /** 用户手动改过（界面要标「已修改」并保留来源）。 */
  edited?: boolean;
  /** 用户改之前的原值，用于「更正信息时保留来源和变更提示」。 */
  originalValue?: string;
  createdAt: number;
}

/** 模型/规则产出的原始形态（还没分配 id、轮次等）。 */
export interface FactDraft {
  kind: FactKind;
  value: string;
  sourceText: string;
  sourceField: 'original' | 'translation';
  certainty: FactCertainty;
}

/** 原话里的「不确定」语气词。命中就整条标 uncertain，不猜。 */
const HEDGE_PATTERNS = [
  /可能/,
  /大概/,
  /也许/,
  /应该/,
  /不确定/,
  /差不多/,
  /\.{2,}$/,
  /\bmaybe\b/i,
  /\bprobably\b/i,
  /\bperhaps\b/i,
  /\bmight\b/i,
  /\bnot sure\b/i,
  /\bi think\b/i,
  /\bkind of\b/i,
  /наверн/i,
  /возможно/i,
  /может/i,
  /たぶん/,
  /かもしれ/,
  /おそらく/,
  /아마/,
  /것 같/,
];

/** 更正句式：「不是三点，是四点」「改成周五」「not Monday but Tuesday」。 */
const CORRECTION_PATTERNS = [
  /不是[^，,。]{1,24}[，,]\s*(?:是|而是)/,
  /改成|改为|应该是|其实是/,
  /\bnot\b[^,.]{1,30}\bbut\b/i,
  /\binstead\b/i,
  /改为|変更/,
  /아니라/,
];

export function looksHedged(text: string): boolean {
  return HEDGE_PATTERNS.some((pattern) => pattern.test(text));
}

export function looksCorrected(text: string): boolean {
  return CORRECTION_PATTERNS.some((pattern) => pattern.test(text));
}

/** 一句话的「确定程度」判定，规则和模型都用它兜底。 */
export function certaintyOf(text: string): FactCertainty {
  if (looksCorrected(text)) return 'corrected';
  if (looksHedged(text)) return 'uncertain';
  return 'stated';
}

// --------------------------------------------------------------------------- //
// 规则提取
// --------------------------------------------------------------------------- //

/**
 * 时间：数字型（14:30 / 3 pm / 3点半 / 3시 30분）。
 *
 * 中文的「三点」只在译文里出现，所以两个字段都要扫 —— 但记下是从哪个字段
 * 取到的，界面上才能说清「这句原话」到底在哪一行。
 */
const TIME_PATTERNS: RegExp[] = [
  /\b\d{1,2}[:：]\d{2}\b/g,
  /\b\d{1,2}\s*(?:am|pm)\b/gi,
  /(?:上午|下午|早上|晚上|中午|凌晨)?[一二三四五六七八九十两\d]{1,3}点(?:半|[一二三四五六七八九十\d]{1,2}分)?/g,
  /\b\d{1,2}時(?:半|\d{1,2}分)?/g,
  /\b\d{1,2}시(?:\s*\d{1,2}분)?/g,
];

/** 日期：相对表达保留原样（「明天」不许被换算成具体日期 —— 那是编造）。 */
const DATE_PATTERNS: RegExp[] = [
  /今[天日]|明[天日]|后[天日]|大后天|本?周[一二三四五六日天]|下周[一二三四五六日天]|这周|下个?月|这个月/g,
  /\b(?:today|tomorrow|tonight|this (?:mon|tues|wednes|thurs|fri|satur|sun)day|next (?:week|month|mon|tues|wednes|thurs|fri|satur|sun)day)\b/gi,
  /\b(?:сегодня|завтра|послезавтра)\b/gi,
  /\bв (?:понедельник|вторник|среду|четверг|пятницу|субботу|воскресенье)\b/gi,
  /(?:今日|明日|明後日|来週|今週|月曜日|火曜日|水曜日|木曜日|金曜日|土曜日|日曜日)/g,
  /(?:오늘|내일|모레|이번 주|다음 주|월요일|화요일|수요일|목요일|금요일|토요일|일요일)/g,
];

/** 金额：必须带货币标记，避免把「3 个人」当钱。 */
const MONEY_PATTERNS: RegExp[] = [
  /[¥$€]\s?\d[\d,]*(?:\.\d+)?/g,
  /\d[\d,]*(?:\.\d+)?\s*(?:元|块|美元|欧元)/g,
  /\b\d[\d,]*(?:\.\d+)?\s*(?:dollars?|usd|rubles?|rub|yen|euros?)\b/gi,
  /\d[\d,]*\s*(?:円|원)/g,
];

/** 数量（不含金额）：个 / 份 / people / pages… */
const QUANTITY_PATTERNS: RegExp[] = [
  /\d[\d,]*\s*(?:个|份|件|张|本|人|台|套|箱)/g,
  /\b\d[\d,]*\s*(?:people|persons?|copies|pages?|items?|boxes|copies)\b/gi,
  /\d[\d,]*\s*(?:명|개|장|권)/g,
];

function matchAll(text: string, patterns: RegExp[]): string[] {
  const out: string[] = [];
  for (const pattern of patterns) {
    // 全局正则带 lastIndex 状态，复用会漏匹配 —— 每次都新建一份。
    const regex = new RegExp(pattern.source, pattern.flags.includes('g') ? pattern.flags : `${pattern.flags}g`);
    let match: RegExpExecArray | null = regex.exec(text);
    let guard = 0;
    while (match && guard < 50) {
      const value = match[0].trim();
      if (value) out.push(value);
      match = regex.exec(text);
      guard += 1;
    }
  }
  return out;
}

function dedupe(values: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const value of values) {
    const key = value.toLowerCase().replace(/\s+/g, ' ').trim();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(value);
  }
  return out;
}

/**
 * 只靠规则就能定下来的事实。
 *
 * 返回的 `sourceField` 标出片段出自原话还是译文 —— 界面和校验都靠它。
 * 同一句话里相同的值只保留一次（中英文各匹配到「3 pm」不会出两张卡）。
 */
export function extractFactsWithRules(item: {
  originalText: string;
  translatedText?: string;
}): FactDraft[] {
  const fields: { field: 'original' | 'translation'; text: string }[] = [
    { field: 'original', text: item.originalText ?? '' },
  ];
  if (item.translatedText && item.translatedText.trim()) {
    fields.push({ field: 'translation', text: item.translatedText });
  }

  const drafts: FactDraft[] = [];
  const seen = new Set<string>();

  const push = (kind: FactKind, values: string[], field: 'original' | 'translation', text: string) => {
    const certainty = certaintyOf(text);
    for (const value of values) {
      const key = `${kind}|${value.toLowerCase()}`;
      if (seen.has(key)) continue;
      seen.add(key);
      drafts.push({ kind, value, sourceText: value, sourceField: field, certainty });
    }
  };

  for (const { field, text } of fields) {
    push('money', matchAll(text, MONEY_PATTERNS), field, text);
    // 时间要在日期之前跑：「下周三点」这种说法很少见，但「明天三点」很常见，
    // 两边都命中时用户看到的是两条不同的卡（日期 + 时间），这是对的。
    push('time', matchAll(text, TIME_PATTERNS), field, text);
    push('date', matchAll(text, DATE_PATTERNS), field, text);
    push('quantity', matchAll(text, QUANTITY_PATTERNS), field, text);
  }

  return mergeBilingual(drafts);
}

/**
 * 把「原文一条 + 译文一条」的同一件事合成一条卡。
 *
 * 没有这一步，用户看到的是
 *     日期  明天      「明天」   · 译文中
 *     日期  Tomorrow  「Tomorrow」
 * ——同一件事两行，而且中文那行的「原文片段」还是中文，等于原文没露出来。
 *
 * 合成之后是
 *     日期  明天      「Tomorrow」 · 译文中
 * 也就是要求里的「简短中文标签 + 外语原文」：值取译文（中文可读），
 * 片段取原文（能核对对方到底怎么说的）。
 *
 * 只在同类事实数量对得上时才配对；多出来的原样保留，绝不硬凑。
 */
function mergeBilingual(drafts: FactDraft[]): FactDraft[] {
  const byKind = new Map<FactKind, { zh: FactDraft[]; src: FactDraft[] }>();
  for (const draft of drafts) {
    let bucket = byKind.get(draft.kind);
    if (!bucket) {
      bucket = { zh: [], src: [] };
      byKind.set(draft.kind, bucket);
    }
    if (draft.sourceField === 'translation') bucket.zh.push(draft);
    else bucket.src.push(draft);
  }

  const merged = new Map<FactDraft, FactDraft>();
  const consumed = new Set<FactDraft>();
  for (const bucket of byKind.values()) {
    const pairs = Math.min(bucket.zh.length, bucket.src.length);
    for (let index = 0; index < pairs; index += 1) {
      const zh = bucket.zh[index];
      const src = bucket.src[index];
      merged.set(zh, { ...zh, sourceText: src.sourceText });
      consumed.add(src);
    }
  }
  if (!merged.size) return drafts;
  return drafts
    .filter((draft) => !consumed.has(draft))
    .map((draft) => merged.get(draft) ?? draft);
}

// --------------------------------------------------------------------------- //
// 校验（模型输出必须过这一关）
// --------------------------------------------------------------------------- //

export interface FactSourceText {
  itemId: string;
  originalText: string;
  translatedText?: string;
  roundIndex: number;
}

function normalize(text: string): string {
  return text.replace(/\s+/g, ' ').trim().toLowerCase();
}

/**
 * 把一批「候选事实」校成可上屏的事实。
 *
 * 丢弃规则（全部是审计要求）：类型不认识、值为空、片段为空、
 * **片段在字幕里找不到**、长度离谱。
 */
export function validateFacts(
  candidates: unknown[],
  source: FactSourceText,
  makeId: (index: number) => string,
): FactItem[] {
  const original = normalize(source.originalText ?? '');
  const translation = normalize(source.translatedText ?? '');
  const out: FactItem[] = [];
  const seen = new Set<string>();

  for (const raw of candidates) {
    if (!raw || typeof raw !== 'object') continue;
    const candidate = raw as Record<string, unknown>;

    const kind = candidate.kind;
    if (typeof kind !== 'string' || !(FACT_KINDS as readonly string[]).includes(kind)) continue;

    const value = typeof candidate.value === 'string' ? candidate.value.trim() : '';
    const sourceText = typeof candidate.sourceText === 'string' ? candidate.sourceText.trim() : '';
    if (!value || !sourceText) continue;
    // 太长的多半是模型把整句话抄回来了，上屏也没法看。
    if (value.length > 60 || sourceText.length > 120) continue;

    const needle = normalize(sourceText);
    if (!needle) continue;
    let field: 'original' | 'translation' | null = null;
    if (original.includes(needle)) field = 'original';
    else if (translation.includes(needle)) field = 'translation';
    // 找不到出处 → 这条是模型编的，不要。
    if (!field) continue;

    const dedupeKey = `${kind}|${normalize(value)}`;
    if (seen.has(dedupeKey)) continue;
    seen.add(dedupeKey);

    const certainty =
      candidate.certainty === 'uncertain' || candidate.certainty === 'corrected'
        ? (candidate.certainty as FactCertainty)
        : certaintyOf(sourceText);

    out.push({
      id: makeId(out.length),
      kind: kind as FactKind,
      value,
      sourceText,
      sourceField: field,
      itemId: source.itemId,
      roundIndex: source.roundIndex,
      certainty,
      status: 'pending',
      createdAt: Date.now(),
    });
  }

  return out;
}

/** 界面上的状态词。有疑问的一律「待核对」，不给百分比。 */
export function factStatusLabel(fact: FactItem): string {
  if (fact.status === 'confirmed') return '已确认';
  if (fact.certainty === 'uncertain') return '待核对';
  if (fact.certainty === 'corrected') return '已更正';
  return '待确认';
}

/**
 * 生成确认句之前的一道闸：句子里的数字必须来自「选中的事实」。
 *
 * 模型很容易顺手补一句「需要三个人参加」——那是**新的承诺**，用户说出来
 * 就把自己坑了。数字是最容易被编进去的具体信息，所以拿它做硬校验。
 */
export function numbersIn(text: string): string[] {
  return (text.match(/\d[\d,.]*/g) ?? []).map((value) => value.replace(/[,\s]/g, ''));
}

export function introducesNewNumbers(sentence: string, factsText: string): boolean {
  const allowed = new Set(numbersIn(factsText));
  return numbersIn(sentence).some((value) => !allowed.has(value));
}

/** 选中若干事实 → 给模型看的一行行文本（顺序即用户看到的顺序）。 */
export function factsForConfirm(facts: FactItem[]): string {
  return facts
    .map((fact) => `- ${FACT_LABELS[fact.kind]}：${fact.value}`)
    .join('\n');
}
