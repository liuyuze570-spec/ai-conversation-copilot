/**
 * 「要不要重建音频管线」的纯判定。
 *
 * 背景：启动请求有两个来源 —— 主进程开机自动启动，和渲染层「设置加载完、
 * 状态还是 idle」时自己再启动一次。两者必然在开机那 1 秒内撞在一起。
 * 无脑 stop→start 的后果是每次开机都白起一个 python 采集进程再杀掉它，
 * 日志里出现两条 `loopback stream started`、会话号从 1 跳到 3。
 *
 * 这里把「配置是否真的变了」做成纯函数，好让 `reliability-unit` 直接测，
 * 而不是靠读日志猜。
 */

export interface PipelineConfig {
  mockMode: boolean;
  captureSystemAudio: boolean;
  captureMicrophone: boolean;
  systemDeviceId: string;
  micDeviceId: string;
  pythonPath: string;
  /** 仅演示模式有意义：示例对话是否自动播放 */
  demoAutoPlay: boolean;
  /** 仅演示模式有意义：示例对话用哪种语言 */
  targetLanguage: string;
}

/**
 * 配置指纹。字段顺序即语义顺序，改动请同步 `.dev/reliability-unit.mjs`。
 *
 * 刻意**不**包含 sttProvider：识别服务商是每次调用现取的，换服务商不需要
 * 拆掉采集，拆了反而会丢当前这段正在录的音频。
 */
export function pipelineSignature(config: PipelineConfig): string {
  const parts = [
    config.mockMode ? 'mock' : 'real',
    config.captureSystemAudio ? 'sys' : '-',
    config.captureMicrophone ? 'mic' : '-',
    config.systemDeviceId || 'default',
    config.micDeviceId || 'default',
    config.pythonPath || '',
  ];
  /*
   * 演示模式的「示例对话 / 目标语言」由引擎自己排期，换了必须重建；
   * 真实模式不依赖它们，所以只在 mock 下计入 —— 否则改个语言就把正在
   * 采集的系统声音拆掉了。
   */
  if (config.mockMode) {
    parts.push(config.demoAutoPlay ? 'auto' : 'manual', config.targetLanguage);
  }
  return parts.join('|');
}

/**
 * 已经有管线在跑、且配置没变 → 这次启动请求什么都不用做。
 * `running` 为空表示当前没有管线（已停止），必须重新启动。
 */
export function shouldRestartPipeline(running: string, config: PipelineConfig): boolean {
  if (!running) return true;
  return running !== pipelineSignature(config);
}
