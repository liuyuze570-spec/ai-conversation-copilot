import { useEffect, useRef, useState } from 'react';
import { COMM_CARDS, cardClipboardText, type CommCard } from '../../shared/comm-cards';

/**
 * 三张固定沟通卡（不联网、不花额度）。
 *
 * 和「帮我回复」的区别：那个要联网、要等几秒、还可能要花钱；这三张是写死的，
 * 点开就显示，断网也能用。真实的场景是**对方正站在你面前等回应** ——
 * 这时候一秒能举起来的一句话，比一段更漂亮的建议有用得多。
 *
 * 只做三件事里的一件：把一句话放大给对方看。不自动朗读、不自动发送，
 * 免得在会议里突然出声或者把你的话发到群里。
 */
export function CommCards({
  onSpeak,
  compact = false,
}: {
  /** 朗读（可选）。只有用户点了「朗读」才会用到，绝不自动触发。 */
  onSpeak: (text: string) => void;
  /** 大字模式：去掉「沟通卡」这行标头，三颗按钮保住一行不折行。 */
  compact?: boolean;
}) {
  const [openId, setOpenId] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const card = COMM_CARDS.find((item) => item.id === openId) ?? null;
  const closeRef = useRef<HTMLButtonElement | null>(null);
  const lastTrigger = useRef<HTMLButtonElement | null>(null);

  /**
   * 打开时把焦点放到「关闭」上，关掉后还给刚才那个按钮。
   *
   * 不这么做的话，键盘用户打开卡片后焦点还留在背后被遮住的按钮上 ——
   * 按 Tab 会在看不见的区域里乱跑。
   */
  useEffect(() => {
    if (!card) return;
    closeRef.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.stopPropagation();
        setOpenId(null);
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      lastTrigger.current?.focus();
      setCopied(false);
    };
  }, [card]);

  const copy = async (target: CommCard) => {
    try {
      await navigator.clipboard.writeText(cardClipboardText(target));
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      // 剪贴板可能被系统策略禁掉；不是致命问题，卡片本身还能给对方看。
      setCopied(false);
    }
  };

  return (
    <>
      <div data-comm-cards className="flex min-w-0 flex-wrap items-center gap-1.5">
        {!compact && <span className="label shrink-0 !text-white/40">沟通卡</span>}
        {COMM_CARDS.map((item) => (
          <button
            key={item.id}
            type="button"
            data-comm-card={item.id}
            title={`${item.note}（不联网，点了立刻显示）`}
            aria-label={`显示沟通卡：${item.zh}`}
            onClick={(event) => {
              lastTrigger.current = event.currentTarget;
              setOpenId(item.id);
            }}
            className="no-drag rounded-xl border border-line bg-ink-850 px-2 py-1 text-[11.5px]
              text-white/75 transition-colors hover:border-accent/40 hover:bg-ink-800 hover:text-white"
          >
            {item.zh}
          </button>
        ))}
      </div>

      {card && (
        <div
          data-comm-overlay
          role="dialog"
          aria-modal="true"
          aria-label={`沟通卡：${card.zh}`}
          className="absolute inset-0 z-30 flex flex-col bg-black/95 px-4 py-4"
        >
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="text-[12px] font-medium text-white/70">{card.zh}</p>
              <p className="mt-0.5 text-[10.5px] leading-relaxed text-white/45">{card.note}</p>
            </div>
            <button
              ref={closeRef}
              type="button"
              data-comm-close
              onClick={() => setOpenId(null)}
              aria-label="关闭沟通卡并回到字幕"
              className="no-drag shrink-0 rounded-lg border border-white/25 px-2.5 py-1 text-[11.5px]
                text-white/80 transition-colors hover:bg-white/10 hover:text-white"
            >
              关闭
            </button>
          </div>

          {/*
            * 给对方看的那句话：纯白 + 大字号 + 纯黑底。
            * 对比度是 21:1（纯白压纯黑），远高于 WCAG AAA 的 7:1 ——
            * 这张卡的作用就是「隔着一米也能读」，不能有任何灰。
            */}
          <p
            data-comm-text
            className="mt-4 flex-1 select-text text-[30px] font-semibold leading-[1.35] text-white"
            style={{ userSelect: 'text' }}
          >
            {card.en}
          </p>

          <div className="mt-3 flex items-center gap-2">
            <button
              type="button"
              data-comm-copy
              onClick={() => void copy(card)}
              className="no-drag rounded-xl border border-white/25 px-3 py-2 text-[12px] text-white/85
                transition-colors hover:bg-white/10 hover:text-white"
            >
              {copied ? '已复制' : '复制英文'}
            </button>
            <button
              type="button"
              data-comm-speak
              onClick={() => onSpeak(card.en)}
              className="no-drag rounded-xl border border-white/25 px-3 py-2 text-[12px] text-white/85
                transition-colors hover:bg-white/10 hover:text-white"
            >
              朗读（需手动点）
            </button>
            <span className="ml-auto text-[10px] text-white/40">不会自动发送给任何人</span>
          </div>
        </div>
      )}
    </>
  );
}
