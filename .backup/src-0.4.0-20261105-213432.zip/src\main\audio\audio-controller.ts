import { ipcMain, type BrowserWindow } from 'electron';
import { IPC, type AudioLevelPayload, type AudioStatusPayload } from '../../shared/ipc';
import { getSettingsStore } from '../settings-store';
import { logger } from '../logger';
import {
  pipelineSignature,
  shouldRestartPipeline,
  startSucceeded,
  type PipelineConfig,
  type StartOutcome,
} from '../../shared/pipeline-gate';
import { hasRecentSignal, pushSignal, type SignalSample } from '../../shared/audio-state';
import { resolveSources } from '../../shared/sources';
import { MockAudioEngine, type AudioEngine } from './mock-engine';
import {
  PythonAudioEngine,
  probeAudio,
  pythonAvailability,
  resetPythonDiscovery,
} from './python-engine';

/**
 * 音频管线的主控。
 *
 * 0.3.x 的三个问题都出在这个文件里，改写时逐个对着修：
 *
 * 1. **启动虚报成功**。旧 `startAudioPipeline()` 是同步函数，`AUDIO_START` 直接
 *    返回 `{ok: true}`，而 sidecar 是 `spawn()` 之后才异步起设备 —— 设备打不开、
 *    被独占、或者 python 根本没起来，界面照样显示「成功」。现在改成等 sidecar
 *    发出 `started` 事件（或明确报错）再回执，超过等待时间就回 `pending`。
 * 2. **引擎死了但指纹还在**。旧逻辑只发一个 error 状态，`runningSignature`
 *    没清 → 用户再点「开始」时 `shouldRestartPipeline()` 认为「配置没变、
 *    已经在跑」，直接跳过。表现出来就是「点多少次都没反应，只能重启软件」。
 *    现在引擎退出会走 `handleEngineDead()`，把指纹一起清掉。
 * 3. **没有「重新连接」**。加一条 IPC（AUDIO_RECONNECT）：强制重建管线，
 *    并重新探测 Python —— 用户不必重启整个软件。
 */

let engine: AudioEngine | null = null;
let boundWindow: BrowserWindow | null = null;
/** 当前管线的配置指纹（'' = 没有管线在跑）。 */
let runningSignature = '';
/** 正在启动中（避免连点两次开始拉起两个进程）。 */
let starting = false;
/**
 * 引擎是否已经拿到设备确认（sidecar 的 `started` 事件）。
 *
 * 和 `starting` 分开记：`starting` 只表示「有一个启动流程在跑」，
 * 而这里表示「设备真的开了」。跳过启动时靠它决定该回推 `listening`
 * 还是 `starting` —— 回错了就是界面写「正在连接」而字幕在滚。
 */
let engineReady = false;

/** 最近的响度采样，只用于判断「最近有没有声音」，不留音频。 */
let signalWindow: SignalSample[] = [];
/** 上一次播报过的「有没有信号」，避免同一状态反复刷屏。 */
let lastSignalState: boolean | null = null;
/** 上一次是否已经发过 no-audio（避免每次 level 都发一条状态）。 */
let noAudioAnnounced = false;

function currentConfig(): PipelineConfig {
  const s = getSettingsStore().get();
  return {
    mockMode: s.mockMode,
    captureSystemAudio: s.audio.captureSystemAudio,
    captureMicrophone: s.audio.captureMicrophone,
    systemDeviceId: s.audio.systemDeviceId || 'default',
    micDeviceId: s.audio.micDeviceId || 'default',
    pythonPath: s.audio.pythonPath || '',
    demoAutoPlay: s.demoAutoPlay,
    targetLanguage: s.targetLanguage,
  };
}

function sendStatus(status: AudioStatusPayload['status'], message: string) {
  const win = boundWindow;
  if (!win || win.isDestroyed()) return;
  win.webContents.send(IPC.AUDIO_STATUS, { status, message });
}

/**
 * 引擎死掉之后的收场。
 *
 * 三件事必须一起做，缺一个就会留下「点开始没反应」的坑：
 * 丢掉引擎引用、**清空配置指纹**、给界面一条带下一步动作的错误。
 */
function handleEngineDead(reason: string) {
  if (!engine && !runningSignature) return;
  const name = engine instanceof MockAudioEngine ? '演示' : '音频';
  engine = null;
  runningSignature = '';
  starting = false;
  engineReady = false;
  signalWindow = [];
  lastSignalState = null;
  noAudioAnnounced = false;
  logger.warn('Audio', `${name}引擎停止：${reason}`);
  sendStatus(
    'error',
    `${name}采集进程已停止（${reason}）。点「重新连接」可以恢复，不需要重启软件。`,
  );
}

/** 响度采样 → 判定「最近 8 秒有没有声音」，并只在该变化时播报。 */
function watchLevel(level: AudioLevelPayload) {
  const now = Date.now();
  signalWindow = pushSignal(signalWindow, { at: now, db: level.db });
  const hasSignal = hasRecentSignal(signalWindow, now);
  if (lastSignalState === hasSignal) return;
  lastSignalState = hasSignal;

  if (!hasSignal) {
    // 从「有声音」掉到「没声音」：可能是对方停了，也可能是设备被拔 / 切走了。
    // 不再用「全程最大音量」判断，所以这种中途掉音现在能显示出来。
    if (!noAudioAnnounced) {
      noAudioAnnounced = true;
      logger.info('Audio', 'no signal in the last 8s window');
      sendStatus('no-audio', '正在采集，但最近 8 秒没有收到声音。');
    }
    return;
  }
  noAudioAnnounced = false;
  sendStatus('listening', level.device ? `正在采集 · ${level.device}` : '正在采集');
}

function attachHooks(target: AudioEngine) {
  target.onDead = (reason) => handleEngineDead(reason);
  target.onLevel = (level) => watchLevel(level);
  target.onDropped = (info) => {
    // 丢了一段音频必须让用户看见「有一句没转写」，不能只写日志。
    logger.warn('Audio', `segment dropped: ${info.reason}`);
    const win = boundWindow;
    if (!win || win.isDestroyed()) return;
    win.webContents.send(IPC.AUDIO_DROPPED, { at: info.at, reason: info.reason });
  };
}

export interface StartReport {
  ok: boolean;
  kind: StartOutcome['kind'];
  message: string;
}

/**
 * 启动（或按需重建）音频管线。
 *
 * `force` 用于「重新连接」：即使配置没变也强制重建，并重新探测 Python
 * （用户可能刚把设备插回去、或者刚结束了一个占用声卡的程序）。
 */
export async function startAudioPipeline(
  win: BrowserWindow,
  options: { force?: boolean } = {},
): Promise<StartReport> {
  const config = currentConfig();
  const alive = engine !== null;

  if (!options.force && !shouldRestartPipeline(runningSignature, config, alive)) {
    logger.info('Audio', 'start skipped (pipeline already running with same settings)');
    /*
     * 跳过也必须回推一次真实状态。
     *
     * 时序是这样的：主进程开机就自启了管线并发过 `listening`，随后渲染层
     * 「设置加载完、status 还是 idle」时又请求一次启动。那一次走的就是这条
     * 跳过分支 —— 如果什么都不发，渲染层之前自己写的「正在连接音频设备…」
     * 就永远留在界面上了（实测：演示模式里整场都写着「正在连接」，而字幕
     * 明明在往下滚）。
     */
    sendStatus(
      engineReady ? 'listening' : 'starting',
      engineReady ? '音频已经在采集' : '正在连接音频，请稍候…',
    );
    return { ok: true, kind: 'skipped', message: '音频已经在采集' };
  }

  // 连点两次「开始」时，第二次不该再拉一个进程。
  if (starting && !options.force) {
    return { ok: false, kind: 'pending', message: '正在连接音频，请稍候…' };
  }

  if (options.force) resetPythonDiscovery();

  stopAudioPipeline();
  boundWindow = win;

  const settings = getSettingsStore().get();
  /*
   * 先确认「这次到底采什么」。没选音源就启动，等于开一个永远没声音的进程，
   * 用户只会以为软件坏了 —— 直接把原因说清楚。
   */
  const plan = resolveSources({
    sourceMode: settings.audio.sourceMode,
    captureSystemAudio: settings.audio.captureSystemAudio,
    captureMicrophone: settings.audio.captureMicrophone,
  });
  if (!plan.items.length) {
    const message = plan.warning ?? '还没有选择音源';
    logger.warn('Audio', `start rejected: ${message}`);
    sendStatus('error', message);
    return { ok: false, kind: 'failed', message };
  }
  if (plan.warning) logger.info('Audio', `source note: ${plan.warning}`);

  starting = true;
  sendStatus('starting', config.mockMode ? '正在准备演示对话…' : '正在连接音频设备…');

  try {
    const created: AudioEngine = config.mockMode
      ? new MockAudioEngine(win)
      : new PythonAudioEngine(win, {
          sourceMode: settings.audio.sourceMode,
          captureSystemAudio: settings.audio.captureSystemAudio,
          captureMicrophone: settings.audio.captureMicrophone,
        });
    attachHooks(created);
    engine = created;
    runningSignature = pipelineSignature(config);
    await created.start();

    /*
     * 等设备确认。真实引擎会等到 sidecar 的 `started` 事件；演示引擎立刻返回。
     * 超时不算失败（进程可能只是慢），但要如实回 `pending` —— 界面写
     * 「正在连接」，而不是「正在采集」。
     */
    const ready = created.waitUntilReady
      ? await created.waitUntilReady(10_000)
      : { ok: true, message: '' };

    starting = false;

    if (!ready.ok) {
      const report: StartReport = {
        ok: false,
        kind: ready.timedOut ? 'pending' : 'failed',
        message: ready.message,
      };
      // 明确失败才清场；单纯超时保留进程，等它自己起来。
      if (report.kind === 'failed') handleEngineDead(ready.message);
      return report;
    }

    engineReady = true;
    sendStatus('listening', ready.message || (config.mockMode ? '演示对话已开始' : '正在采集'));
    logger.info('Audio', `pipeline ready (${config.mockMode ? 'mock' : 'real'})`);
    return { ok: true, kind: 'running', message: ready.message || '正在采集' };
  } catch (error) {
    starting = false;
    const message = `启动音频失败：${String(error)}`;
    logger.error('Audio', message);
    handleEngineDead('启动失败');
    return { ok: false, kind: 'failed', message };
  }
}

export function stopAudioPipeline() {
  if (engine) {
    try {
      engine.stop();
    } catch {
      /* 进程可能已经没了 */
    }
    engine = null;
  }
  runningSignature = '';
  starting = false;
  engineReady = false;
  signalWindow = [];
  lastSignalState = null;
  noAudioAnnounced = false;
}

/** 引擎是否真的在跑（配置指纹 + 对象都在才算）。 */
export function isPipelineRunning(): boolean {
  return engine !== null && runningSignature !== '';
}

/** Called by the window layer to release resources on quit. */
export function disposeAudio() {
  try {
    stopAudioPipeline();
    logger.info('Audio', 'pipeline disposed');
  } catch (error) {
    logger.error('Audio', `dispose failed: ${String(error)}`);
  }
}

export function registerAudioIpc(win: BrowserWindow) {
  boundWindow = win;

  ipcMain.handle(IPC.AUDIO_START, async () => {
    try {
      const settings = getSettingsStore().get();
      logger.info(
        'Audio',
        `start requested (mock=${settings.mockMode}, source=${settings.audio.sourceMode}, system=${settings.audio.captureSystemAudio}, mic=${settings.audio.captureMicrophone})`,
      );
      const report = await startAudioPipeline(win);
      return { ...report, ok: startSucceeded(report) };
    } catch (error) {
      logger.error('Audio', `start failed: ${String(error)}`);
      return { ok: false, kind: 'failed' as const, message: String(error) };
    }
  });

  /**
   * 「重新连接音频」。
   *
   * 不做这一步的话，sidecar 死掉之后用户唯一的出路是重启整个软件 —— 而这在
   * 一场正在进行的会议里等于事故。这里强制重建（配置没变也重建）并重新探测
   * Python，把「刚才那个解释器被杀了 / 设备刚插回来」这类情况一并救回来。
   */
  ipcMain.handle(IPC.AUDIO_RECONNECT, async () => {
    logger.info('Audio', 'reconnect requested');
    resetPythonDiscovery();
    const report = await startAudioPipeline(win, { force: true });
    return { ...report, ok: startSucceeded(report) };
  });

  ipcMain.handle(IPC.AUDIO_STOP, async () => {
    stopAudioPipeline();
    return { ok: true };
  });

  ipcMain.handle(IPC.AUDIO_DEMO_LINE, async (_event, text?: unknown) => {
    const settings = getSettingsStore().get();
    if (!settings.mockMode) {
      return { ok: false, message: '真实模式下没有示例对话，请先开启演示模式' };
    }
    // Make sure a mock engine exists even while auto-play is switched off.
    if (!engine || !(engine instanceof MockAudioEngine)) {
      stopAudioPipeline();
      const created = new MockAudioEngine(win);
      attachHooks(created);
      engine = created;
      runningSignature = pipelineSignature(currentConfig());
      await created.start();
    }
    /*
     * 指定文本只给自检用（COPILOT_SELFTEST=1）。不设这个开关时行为完全不变，
     * 仍然从内置语料里取一句 —— 免得界面上的「说一句示例」变成任意文本注入口。
     */
    if (typeof text === 'string' && text.trim() && process.env.COPILOT_SELFTEST === '1') {
      const said = (engine as MockAudioEngine).sayText(text.trim());
      return { ok: true, text: said };
    }
    const said = (engine as MockAudioEngine).sayOnce();
    return { ok: true, text: said };
  });

  ipcMain.handle(IPC.AUDIO_DEVICES, async () => {
    const settings = getSettingsStore().get();
    if (settings.mockMode) {
      return [
        { id: 'mock-system', name: '系统音频（演示）', kind: 'system' as const },
        { id: 'mock-mic', name: '麦克风（演示）', kind: 'mic' as const },
      ];
    }
    try {
      return await new PythonAudioEngine(win).listDevices();
    } catch (error) {
      logger.warn('Audio', `device enumeration failed: ${String(error)}`);
      return [];
    }
  });

  /**
   * Record a few seconds and report the real level. This is the answer to
   * "why is the subtitle list empty?" — it separates capture from recognition.
   * Also re-resolves Python so filling in a path takes effect immediately.
   */
  ipcMain.handle(IPC.AUDIO_PROBE, async (_event, mode: 'loopback' | 'mic' = 'loopback') => {
    resetPythonDiscovery();
    const availability = pythonAvailability();
    if (!availability.available) {
      return {
        ok: false,
        mode,
        device: '',
        deviceId: '',
        rate: 0,
        channels: 0,
        rms: 0,
        peak: 0,
        db: -120,
        durationMs: 0,
        hasSignal: false,
        message:
          '安装包自带的音频组件没找到（可能被杀毒软件拦截，或安装不完整）。建议重新安装本软件；也可以在设置 → 音频里手动指定 python.exe 的路径。',
      };
    }
    return probeAudio(mode, 2.5);
  });
}

export function getBoundWindow(): BrowserWindow | null {
  return boundWindow;
}
