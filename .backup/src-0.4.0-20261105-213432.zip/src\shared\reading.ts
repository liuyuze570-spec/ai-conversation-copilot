/**
 * 字幕阅读区的排版规则（纯函数，能直接单测）。
 *
 * 背景：这个软件是给听障使用者「靠中文译文拿信息」用的，而旧默认是
 * 原文 15px、译文再减 2px（13px）并且用 `text-white/45` 压暗 ——
 * 等于把最该看清的那一行做成了最不该看清的那一行。这一版把译文的字号、
 * 颜色、行距都提到主阅读级别，并且**允许原文与译文分开调**。
 *
 * 这里只放规则，不放 React：字号钳制、阅读模式、对比度计算都能脱离界面验证。
 */

/** 译文可以调到的范围。18 是「小屏也能读」的下限，40 是 460px 宽里不折成柱状的上限。 */
export const TRANSLATION_FONT_MIN = 18;
export const TRANSLATION_FONT_MAX = 40;
export const TRANSLATION_FONT_DEFAULT = 23;

/** 原文范围：原文是核对用的，允许比译文小，但不许小到看不清。 */
export const ORIGINAL_FONT_MIN = 12;
export const ORIGINAL_FONT_MAX = 32;
export const ORIGINAL_FONT_DEFAULT = 15;

export type ReadingMode = 'both' | 'translation-first' | 'original-only';

export const READING_MODES: { value: ReadingMode; label: string; hint: string }[] = [
  {
    value: 'both',
    label: '原文 + 译文',
    hint: '原文小一号、译文大字，适合边看边核对',
  },
  {
    value: 'translation-first',
    label: '先看译文',
    hint: '译文在上、原文折叠成一行小字，适合只想快速抓住意思',
  },
  {
    value: 'original-only',
    label: '只看原文',
    hint: '外语原文放大显示，不显示译文',
  },
];

export function clampNumber(value: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, Math.round(value)));
}

export function clampTranslationFont(value: number): number {
  return clampNumber(value, TRANSLATION_FONT_MIN, TRANSLATION_FONT_MAX);
}

export function clampOriginalFont(value: number): number {
  return clampNumber(value, ORIGINAL_FONT_MIN, ORIGINAL_FONT_MAX);
}

export interface ReadingPrefs {
  originalFontSize: number;
  translationFontSize: number;
  readingMode: ReadingMode;
  highContrast: boolean;
}

export interface SubtitleLike {
  fontSize?: number;
  originalFontSize?: number;
  translationFontSize?: number;
  readingMode?: ReadingMode;
  highContrast?: boolean;
  showTranslation?: boolean;
}

/**
 * 把（可能是旧版）设置规整成一份完整的阅读偏好。
 *
 * 老设置文件里只有一个 `fontSize`（默认 15）。迁移时不能直接把它当译文
 * 字号 —— 那等于把 13px 的老习惯原封不动搬到新版本。规则：老字段只决定
 * 原文，译文一律从默认 23 起步，用户想要更小可以自己调（下限 18）。
 */
export function readingPrefs(subtitle: SubtitleLike): ReadingPrefs {
  const legacy = typeof subtitle.fontSize === 'number' ? subtitle.fontSize : ORIGINAL_FONT_DEFAULT;
  const original = clampOriginalFont(
    typeof subtitle.originalFontSize === 'number' ? subtitle.originalFontSize : legacy,
  );
  const translation = clampTranslationFont(
    typeof subtitle.translationFontSize === 'number'
      ? subtitle.translationFontSize
      : TRANSLATION_FONT_DEFAULT,
  );
  return {
    originalFontSize: original,
    translationFontSize: translation,
    readingMode: subtitle.readingMode ?? 'both',
    highContrast: subtitle.highContrast ?? false,
  };
}

/** 译文是不是主阅读对象（决定译文在上、字号是否加粗）。 */
export function translationIsPrimary(prefs: ReadingPrefs): boolean {
  return prefs.readingMode !== 'original-only';
}

// ---------------------------------------------------------------------------
// 对比度
// ---------------------------------------------------------------------------

export interface Rgb {
  r: number;
  g: number;
  b: number;
}

export function hexToRgb(hex: string): Rgb {
  const clean = hex.trim().replace('#', '');
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((char) => char + char)
          .join('')
      : clean.padEnd(6, '0').slice(0, 6);
  return {
    r: parseInt(full.slice(0, 2), 16) || 0,
    g: parseInt(full.slice(2, 4), 16) || 0,
    b: parseInt(full.slice(4, 6), 16) || 0,
  };
}

/**
 * 半透明文字压到底色上之后的实际颜色。
 *
 * 直接拿 `#ffffff` 和底色算对比度会得出一个虚假的好成绩 —— 界面上那行
 * 字真正显示出来是 `white/45`，也就是 45% 的白压在深底上。必须先把 alpha
 * 合成进来，算出来的才是用户眼睛看到的对比度。
 */
export function compositeOver(fgHex: string, alpha: number, bgHex: string): Rgb {
  const fg = hexToRgb(fgHex);
  const bg = hexToRgb(bgHex);
  const a = Math.min(1, Math.max(0, alpha));
  return {
    r: Math.round(fg.r * a + bg.r * (1 - a)),
    g: Math.round(fg.g * a + bg.g * (1 - a)),
    b: Math.round(fg.b * a + bg.b * (1 - a)),
  };
}

/** WCAG 相对亮度。 */
export function relativeLuminance(color: Rgb): number {
  const channel = (value: number) => {
    const c = value / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  };
  return 0.2126 * channel(color.r) + 0.7152 * channel(color.g) + 0.0722 * channel(color.b);
}

/** WCAG 对比度：1:1 ～ 21:1。正文建议 ≥ 4.5，大字号 ≥ 3。 */
export function contrastRatio(foreground: Rgb, background: Rgb): number {
  const a = relativeLuminance(foreground);
  const b = relativeLuminance(background);
  const lighter = Math.max(a, b);
  const darker = Math.min(a, b);
  return (lighter + 0.05) / (darker + 0.05);
}

export function contrastOf(fgHex: string, alpha: number, bgHex: string): number {
  return contrastRatio(compositeOver(fgHex, alpha, bgHex), hexToRgb(bgHex));
}

/**
 * 实际使用的文字颜色（含透明度）。
 *
 * 关键点：**译文不再因为「是译文」而被压暗**。普通模式下译文用 0.88 的白，
 * 高对比模式下原文和译文都是纯白，底色压到纯黑。
 */
export const TEXT_TOKENS = {
  normal: {
    background: '#0b0e14',
    original: { color: '#ffffff', alpha: 0.96 },
    translation: { color: '#ffffff', alpha: 0.88 },
    secondary: { color: '#ffffff', alpha: 0.55 },
  },
  high: {
    background: '#000000',
    original: { color: '#ffffff', alpha: 1 },
    translation: { color: '#ffffff', alpha: 1 },
    secondary: { color: '#ffffff', alpha: 0.86 },
  },
} as const;

export function textTokens(highContrast: boolean) {
  return highContrast ? TEXT_TOKENS.high : TEXT_TOKENS.normal;
}

/**
 * 阅读区高度是否已经很紧 —— 决定要不要把「帮我回复」这类次要区收起来。
 *
 * 460×640 的悬浮窗里，译文 40px 时一行就能占掉 60px 以上。这时候还留着
 * 语气选择、场景切换、中文输入框，字幕会被压到只剩一两行；用户调大字号
 * 本来就是为了看清，结果看到的更少。所以超过 26px 就切「精简底栏」。
 */
export function needsCompactChrome(translationFontSize: number): boolean {
  return translationFontSize >= 26;
}
