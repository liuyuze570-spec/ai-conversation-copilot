import type { FactCertainty, FactKind } from './facts';

/**
 * 三组可体验样例（比赛要求「至少 3 条可体验的测试样例 / 3 个输入输出样例」）。
 *
 * ⚠️ 证据等级必须写清楚，不能混：
 *
 * - 这里的 `original` / `translated` 是**预置文本**，把它们塞进字幕区只能证明
 *   「界面能读、事实卡能认」，**不能**当作真实识别或真实翻译的结果。
 * - 自动化测试跑 `extractFactsWithRules()` 只能证明**规则逻辑**，不能证明语音
 *   识别准不准。
 * - 只有「真实音频 → 真实 STT → 真实 LLM 翻译」走完一遍，才算那条链路的测试
 *   结果（见交付文档里的记录表，未执行的项一律写「未执行」）。
 *
 * 三句话分别覆盖最容易被听错的三类信息：时间（含相对表达）、否定 + 改期、
 * 金额纠正。
 */

export interface SampleExpectation {
  kind: FactKind;
  /** 值里必须包含的片段（大小写不敏感）。 */
  includes: string;
  certainty?: FactCertainty;
}

export interface SampleCase {
  id: string;
  title: string;
  /** 对方原话（外语）。 */
  original: string;
  /** 参考译文 —— 人工写的，不是模型实测输出。 */
  translated: string;
  /** 这句要抓住的重点（人话）。 */
  focus: string[];
  expect: SampleExpectation[];
  /** 不允许出现的值（否定项被当成确定值时就是这种）。 */
  forbidValues?: string[];
}

export const SAMPLE_CASES: SampleCase[] = [
  {
    id: 'sample-time',
    title: '样例 1 · 明天下午三点前交报告',
    original: 'Please send the report by 3 p.m. tomorrow.',
    translated: '请在明天下午三点前把报告发过来。',
    focus: ['事项：发报告', '时间：下午三点', '日期：明天（相对表达，不换算成具体日期）'],
    expect: [
      { kind: 'time', includes: '3 p' },
      { kind: 'date', includes: 'tomorrow' },
    ],
    // 「明天」不能被悄悄换成某个具体日期。
    forbidValues: ['2026', 'November', '11月'],
  },
  {
    id: 'sample-moved',
    title: '样例 2 · 会议从周二改到周四 10:30',
    original: 'The meeting is not on Tuesday. It has moved to Thursday at 10:30 a.m.',
    translated: '会议不在周二，改到周四上午 10 点 30 分了。',
    focus: ['否定：不是周二', '更正：周四', '时间：上午 10:30'],
    expect: [
      { kind: 'date', includes: 'thursday' },
      { kind: 'time', includes: '10:30' },
      // 周二必须作为「被否定」出现，不能是一条中性的日期卡。
      { kind: 'date', includes: 'tuesday', certainty: 'corrected' },
    ],
    forbidValues: ['Tuesday'],
  },
  {
    id: 'sample-budget',
    title: '样例 3 · 预算一万五，不是五万',
    original: 'The budget is fifteen thousand, not fifty thousand.',
    translated: '预算是一万五千，不是五万。',
    focus: ['金额：15000', '纠正：不是 50000', '两个数字都要留着，别只留一个'],
    expect: [
      { kind: 'money', includes: 'fifteen thousand' },
      { kind: 'money', includes: 'fifty thousand', certainty: 'corrected' },
    ],
    forbidValues: ['fifty thousand'],
  },
];

export function sampleById(id: string): SampleCase | undefined {
  return SAMPLE_CASES.find((item) => item.id === id);
}

/** 样例卡上的一行摘要（设置页 / 交付文档共用）。 */
export function sampleSummary(sample: SampleCase): string {
  return sample.focus.join(' · ');
}
