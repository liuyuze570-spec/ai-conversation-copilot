import type { ConversationItem } from '../../shared/types';
import type { HistoryFact, HistoryMessage, HistoryMessageState } from '../../shared/history';
import { describeHistoryError } from '../../shared/history';
import { useConversationStore } from '../stores/conversation';
import { useFactsStore } from '../stores/facts';
import { useHistoryStore } from '../stores/history';
import { useSettingsStore } from '../stores/settings';
import { useUiStore } from '../stores/ui';

/**
 * 把「界面上正在流动的字幕」写进本地数据库。
 *
 * 只有这一个写入者。以前是 `useSessions` 在 items 变化后 debounce 800ms 调
 * `saveCurrent`，把**整个数组**塞进一个内存对象 —— 于是：
 *  - 关掉窗口就没了（内存）；
 *  - 数组被 `slice(0, 50)` 截断，第 51 段把最老的一段挤掉；
 *  - 「保存」其实只是覆盖内存，没有任何回执，界面无从知道到底存没存。
 *
 * 现在的规则：
 *  1. **每条消息一个 id**，转写先到先写，译文后到用同一个 id 覆盖同一行；
 *  2. 写入是**小批量 + debounce 300ms**，不是每敲一个字就落盘；
 *  3. 只有拿到主进程回执才把界面标成「已保存」，失败就标「尚未保存」并允许重试；
 *  4. 新建会话前先把待写队列冲干净，绝不用「当前内存里的一小部分」覆盖旧会话。
 */

const FLUSH_DELAY_MS = 300;
const PARTIAL_FLUSH_DELAY_MS = 900;
const MAX_RETRY_DELAY_MS = 30_000;

let started = false;
let unsubscribers: (() => void)[] = [];

let sessionId: string | null = null;
/** 每条消息「已经交给主进程」的样子，用来判断有没有变化、以及补写 reply。 */
const known = new Map<string, HistoryMessage>();
const pending = new Set<string>();
let timer: ReturnType<typeof setTimeout> | null = null;
let inFlight = false;
let failures = 0;
let pendingReplyFor: string | null = null;
let pendingReplyText = '';

function nextSessionId(): string {
  const rand = Math.random().toString(36).slice(2, 8);
  return `s-${Date.now().toString(36)}-${rand}`;
}

function messageStateOf(item: ConversationItem): HistoryMessageState {
  if (item.partial) return 'partial';
  const state = item.translationState;
  if (state === 'failed') return 'failed';
  if (state === 'cancelled') return 'cancelled';
  if (state === 'pending') return 'pending';
  return 'final';
}

function toHistoryMessage(item: ConversationItem): HistoryMessage {
  return {
    id: item.id,
    sessionId: sessionId ?? '',
    seq: 0,
    ts: item.timestamp,
    speaker: item.speaker,
    source: item.speaker === 'foreign' ? 'system' : 'mic',
    original: item.originalText,
    translation: item.translatedText ?? '',
    romanization: item.romanization ?? '',
    syllables: undefined,
    state: messageStateOf(item),
    confidence: item.confidence,
    translationError: item.translationError,
    edited: false,
    correction: item.correction,
  };
}

function sameRow(a: HistoryMessage, b: HistoryMessage): boolean {
  return (
    a.original === b.original &&
    a.translation === b.translation &&
    a.romanization === b.romanization &&
    a.state === b.state &&
    a.correction === b.correction &&
    a.confidence === b.confidence
  );
}

function ensureSession(): string {
  if (sessionId) return sessionId;
  const settings = useSettingsStore.getState().settings;
  sessionId = nextSessionId();
  known.clear();
  pending.clear();
  void window.copilot.historyEnsureSession({
    id: sessionId,
    language: settings.targetLanguage,
    scenario: settings.scenarioMode,
    sourceMode: settings.audio.sourceMode,
  });
  return sessionId;
}

function schedule(delay = FLUSH_DELAY_MS) {
  if (timer) clearTimeout(timer);
  timer = setTimeout(() => {
    timer = null;
    void flushHistory();
  }, delay);
}

/** 收集「和上次写过的样子不一样」的消息。 */
function collect(): HistoryMessage[] {
  const items = useConversationStore.getState().items;
  const out: HistoryMessage[] = [];
  for (const item of items) {
    if (!item.originalText.trim() && !item.partial) continue;
    const row = toHistoryMessage(item);
    const before = known.get(item.id);
    if (before && sameRow(before, row)) continue;
    out.push(row);
  }
  return out;
}

/**
 * 立刻把待写内容刷到数据库。
 *
 * 返回是否成功 —— 「新建会话」「关闭记录面板」这类动作会等它，避免
 * 旧会话的最后几条消息还没落盘就被切走。
 */
export async function flushHistory(): Promise<boolean> {
  if (inFlight) return false;
  const rows = collect();
  if (!rows.length && !pendingReplyText) {
    useHistoryStore.getState().setPendingCount(0);
    return true;
  }

  const id = ensureSession();
  if (pendingReplyText && pendingReplyFor) {
    const target = rows.find((row) => row.id === pendingReplyFor) ?? known.get(pendingReplyFor);
    if (target) {
      const patched: HistoryMessage = { ...target, reply: pendingReplyText };
      const index = rows.findIndex((row) => row.id === patched.id);
      if (index >= 0) rows[index] = patched;
      else rows.push(patched);
      known.set(patched.id, patched);
    }
  }
  pendingReplyText = '';
  pendingReplyFor = null;

  const store = useHistoryStore.getState();
  inFlight = true;
  store.setPendingCount(rows.length);
  store.setSaveState('saving');
  try {
    const result = await window.copilot.historyUpsert({ sessionId: id, messages: rows });
    if (result.ok) {
      for (const row of rows) known.set(row.id, row);
      failures = 0;
      store.setSaveState('saved', { at: Date.now() });
      store.setPendingCount(collect().length);
      return true;
    }
    failures += 1;
    store.setSaveState('failed', { error: result.error });
    store.setPendingCount(rows.length);
    schedule(Math.min(MAX_RETRY_DELAY_MS, 1000 * 2 ** Math.min(failures, 5)));
    return false;
  } catch (error) {
    failures += 1;
    store.setSaveState('failed', { error: describeHistoryError(error) });
    schedule(Math.min(MAX_RETRY_DELAY_MS, 1000 * 2 ** Math.min(failures, 5)));
    return false;
  } finally {
    inFlight = false;
    pending.clear();
  }
}

/** 用户点了「重试保存」。 */
export async function retrySave(): Promise<boolean> {
  failures = 0;
  // 强制重发一次全部：上次失败时 known 里没有这些行。
  known.clear();
  return flushHistory();
}

/**
 * 开一段新会话。
 *
 * 先把旧的写干净 —— 顺序反了就会「新会话建好了，旧会话最后三句还没落盘」。
 */
export async function startNewHistorySession(): Promise<void> {
  await flushHistory();
  sessionId = null;
  known.clear();
  pending.clear();
  pendingReplyText = '';
  pendingReplyFor = null;
  useHistoryStore.getState().setSaveState('idle');
}

/**
 * 打开一段已保存的记录后，后续字幕追加到**这一段**里。
 *
 * 为什么不新开一段：用户点开旧记录、然后继续说话，那是同一场对话的延续。
 * 新开一段会让「刚才看到的上下文」和「新说的话」分成两条记录。
 */
export function attachHistorySession(id: string, seed: ConversationItem[]): void {
  sessionId = id;
  known.clear();
  pending.clear();
  // 已经存在的行不重发（幂等，但没必要每次打开都写一遍）。
  for (const item of seed) {
    if (!item.originalText.trim()) continue;
    known.set(item.id, { ...toHistoryMessage(item), sessionId: id });
  }
  useHistoryStore.getState().setSaveState('idle');
}

export function currentHistorySessionId(): string | null {
  return sessionId;
}

/** 记录「AI 回复已经展示给用户了」。 */
export function recordReply(text: string): void {
  const trimmed = text.trim();
  if (!trimmed) return;
  const state = useUiStore.getState();
  const items = useConversationStore.getState().items.filter(
    (item) => item.speaker === 'foreign' && !item.partial,
  );
  const index = Math.max(0, (state.repliesRound ?? items.length) - 1);
  const target = items[index] ?? items[items.length - 1];
  if (!target) return;
  pendingReplyFor = target.id;
  pendingReplyText = trimmed;
  schedule(FLUSH_DELAY_MS);
}

/** 事实卡的结果也要落盘：打开旧记录时信息不能缺一块。 */
export function recordFacts(): void {
  if (!sessionId) return;
  const items = useFactsStore.getState().items;
  if (!items.length) return;
  const facts: HistoryFact[] = items.map((item) => ({
    id: item.id,
    sessionId: sessionId as string,
    messageId: item.itemId,
    kind: String(item.kind),
    value: item.value,
    sourceText: item.sourceText ?? '',
    certainty: item.certainty ?? 'stated',
    confirmed: item.status === 'confirmed',
    edited: item.edited,
    createdAt: Date.now(),
  }));
  void window.copilot.historySaveFacts({ sessionId, facts });
}

/** 应用启动时调一次（幂等）。 */
export function startHistorySync(): void {
  if (started) return;
  started = true;

  unsubscribers.push(
    useConversationStore.subscribe((state, prev) => {
      if (state.items === prev.items && state.marks === prev.marks) return;
      // 只有真的有内容才建会话：空白对话不该在库里留一行。
      if (!state.items.length) return;
      if (!sessionId) {
        // 第一句字幕到了 —— 会话在这一刻就有了稳定 id。
        ensureSession();
      }
      const hasPartial = state.items.some((item) => item.partial);
      schedule(hasPartial ? PARTIAL_FLUSH_DELAY_MS : FLUSH_DELAY_MS);
    }),
  );

  unsubscribers.push(
    useUiStore.subscribe((state, prev) => {
      if (state.suggestions === prev.suggestions) return;
      if (!state.suggestions.length) return;
      const first = state.suggestions[0]?.english;
      if (first) recordReply(first);
    }),
  );

  unsubscribers.push(
    useFactsStore.subscribe((state, prev) => {
      if (state.items === prev.items) return;
      recordFacts();
    }),
  );
}

export function stopHistorySync(): void {
  for (const off of unsubscribers) off();
  unsubscribers = [];
  if (timer) clearTimeout(timer);
  timer = null;
  started = false;
}

/** 界面上的「保存状态」文案（纯函数，方便单测）。 */
export function saveStateLabel(state: string, pendingCount: number): string {
  switch (state) {
    case 'saving':
      return '正在保存…';
    case 'pending':
      return pendingCount > 0 ? `待保存 ${pendingCount} 条` : '待保存';
    case 'saved':
      return '已保存';
    case 'failed':
      return '尚未保存';
    default:
      return '待保存';
  }
}
