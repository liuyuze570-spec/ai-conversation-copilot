import type { ReplySuggestion } from '../../shared/types';
import type { PronunciationSettings, ScenarioMode } from '../../shared/types';
import { readingPrefs } from '../../shared/reading';
import { useSettingsStore } from '../stores/settings';
import { IconSpeaker } from './icons';
import type { CopilotMode } from '../hooks/useCopilot';

interface Props {
  suggestion: ReplySuggestion;
  pronunciation: PronunciationSettings;
  /** What is being listened to — changes what each card is labelled. */
  scenario: ScenarioMode;
  speaking: boolean;
  onSpeak: () => void;
  /** Replay at a slower rate so the user can read along while practising. */
  onSpeakSlow: () => void;
  onRefine: (mode: CopilotMode) => void;
}

/** Same three cards, but their meaning depends on what you are listening to. */
const KIND_LABEL: Record<ScenarioMode, Record<ReplySuggestion['kind'], string>> = {
  conversation: { simple: '简单回答', natural: '自然聊天', continue: '延续话题' },
  video: { simple: '简单反应', natural: '自然回应', continue: '追问一句' },
  exam: { simple: '关键要点', natural: '参考答案', continue: '拓展表达' },
};

/**
 * 卡片按「用途」分色，而不是按顺序。
 *
 * 颜色只作为识别锚点（标签底色 + 左侧细轨），不铺满卡片 —— 三张卡同时出现时
 * 才不会变成调色盘。
 */
const KIND_TONE: Record<ReplySuggestion['kind'], { chip: string; rail: string }> = {
  simple: { chip: 'bg-ok/12 text-ok/90', rail: 'bg-ok/45' },
  natural: { chip: 'bg-accent/15 text-accent-soft/90', rail: 'bg-accent/50' },
  continue: { chip: 'bg-warn/12 text-warn/85', rail: 'bg-warn/45' },
};

export function ReplyCard({
  suggestion,
  pronunciation,
  scenario,
  speaking,
  onSpeak,
  onSpeakSlow,
  onRefine,
}: Props) {
  const hasPron =
    (pronunciation.chinesePronunciation && suggestion.chinesePronunciation) ||
    (pronunciation.syllables && suggestion.syllables?.length) ||
    (pronunciation.syllables && suggestion.romanization) ||
    (pronunciation.ipa && suggestion.ipa);

  const tone = KIND_TONE[suggestion.kind];

  /*
   * 回复卡片里的中文谐音也要跟着「谐音字号」走。
   *
   * 它和字幕里的谐音是同一类内容，用户把谐音调大是为了跟着念 ——
   * 卡片里却还是 13.5px 小字，等于调了没用。
   */
  const subtitle = useSettingsStore((state) => state.settings.subtitle);
  const romanizationFontSize = readingPrefs(subtitle).romanizationFontSize;

  return (
    <div
      data-reply-card
      className="animate-fade-in-up relative overflow-hidden rounded-2xl border border-line-soft
        bg-ink-800/70 pl-3 pr-3 py-2.5 transition-colors duration-200 hover:border-line"
    >
      {/* 左侧细轨：一眼分清「简单反应 / 自然回应 / 追问一句」。 */}
      <span className={`absolute inset-y-2 left-0 w-[2px] rounded-full ${tone.rail}`} />

      <div className="mb-1.5 flex items-center justify-between gap-2">
        <span className={`chip ${tone.chip}`}>{KIND_LABEL[scenario][suggestion.kind]}</span>
        <div className="no-drag flex shrink-0 items-center gap-0.5">
          <button
            onClick={onSpeak}
            title="播放发音"
            className={`grid h-6 w-6 place-items-center rounded-lg transition-colors duration-150
              ${speaking ? 'bg-accent/25 text-accent-soft' : 'text-white/45 hover:bg-ink-700 hover:text-white'}`}
          >
            <IconSpeaker size={13} />
          </button>
          <button
            onClick={onSpeakSlow}
            title="慢速播放（0.7x），方便跟着念"
            className="grid h-6 place-items-center rounded-lg px-1.5 text-[10px] text-white/40
              transition-colors duration-150 hover:bg-ink-700 hover:text-white"
          >
            0.7x
          </button>
        </div>
      </div>

      <p className="text-[14.5px] font-medium leading-snug tracking-[0.005em] text-white/[0.95]">
        {suggestion.english}
      </p>
      <p className="mt-1 text-[12px] leading-snug text-white/45">{suggestion.chinese}</p>

      {/* The sound hint is what the user actually reads out loud — give it the
          strongest visual weight after the sentence itself. */}
      {hasPron && (
        <div
          data-pron-block
          className="mt-2 rounded-xl border border-accent/15 bg-accent/[0.06] px-2.5 py-1.5"
        >
          {pronunciation.chinesePronunciation && suggestion.chinesePronunciation ? (
            // data-pron-chinese：自检要断言这一行是「干净的中文谐音」——
            // 曾经出现模型把中文拼音/注音塞进来（实测 `太 ɡe 棒 了 我 ɑm…`）。
            <p
              data-pron-chinese
              className="font-medium leading-snug tracking-[0.02em] text-accent-soft"
              style={{ fontSize: `${romanizationFontSize}px` }}
            >
              {suggestion.chinesePronunciation}
            </p>
          ) : null}

          {(pronunciation.syllables && suggestion.syllables?.length) ||
          (pronunciation.syllables && suggestion.romanization) ? (
            <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-[2px]">
              {pronunciation.syllables && suggestion.romanization ? (
                <span className="font-mono text-[10.5px] text-white/45">
                  {suggestion.romanization}
                </span>
              ) : null}
              {pronunciation.syllables && suggestion.syllables?.length ? (
                <span className="text-[10.5px] text-white/30">
                  {suggestion.syllables.join(' · ')}
                </span>
              ) : null}
            </div>
          ) : null}

          {pronunciation.ipa && suggestion.ipa ? (
            <p data-pron-ipa className="mt-[3px] font-mono text-[10.5px] text-white/30">
              {suggestion.ipa}
            </p>
          ) : null}
        </div>
      )}

      <div className="mt-2 flex flex-wrap gap-1">
        <MiniButton onClick={() => onRefine('simplify')}>简单一点</MiniButton>
        <MiniButton onClick={() => onRefine('rephrase')}>换一种说法</MiniButton>
        <MiniButton onClick={() => onRefine('natural')}>更自然</MiniButton>
      </div>
    </div>
  );
}

function MiniButton({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="no-drag rounded-lg border border-line-soft px-2 py-[3px] text-[11px] text-white/50
        transition-colors duration-150 hover:border-line hover:bg-ink-800 hover:text-white/85"
    >
      {children}
    </button>
  );
}
